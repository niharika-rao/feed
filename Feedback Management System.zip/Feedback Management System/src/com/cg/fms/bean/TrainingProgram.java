package com.cg.fms.bean;

import java.time.LocalDate;
import java.util.Date;

public class TrainingProgram {

	int TrainingCode;
	int CourseCode;
	int FacultyCode;
	String StartDateStr;
	String EndDateStr;
	String courseName;
	
	Date startDate;
	Date endDate;
	
	
	public String getStartDateStr() {
		return StartDateStr;
	}
	public void setStartDateStr(String startDateStr) {
		StartDateStr = startDateStr;
	}
	public String getEndDateStr() {
		return EndDateStr;
	}
	public void setEndDateStr(String endDateStr) {
		EndDateStr = endDateStr;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getTrainingCode() {
		return TrainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		TrainingCode = trainingCode;
	}
	public int getCourseCode() {
		return CourseCode;
	}
	public void setCourseCode(int courseCode) {
		CourseCode = courseCode;
	}
	public int getFacultyCode() {
		return FacultyCode;
	}
	public void setFacultyCode(int facultyCode) {
		FacultyCode = facultyCode;
	}
	
	
}
