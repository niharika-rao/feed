package com.cg.fms.bean;

public class Feedback {

	private int trainingCode;
	private int participantID;
	private int FBPrsComm;
	private int FBClrfyDbts;
	private int FBTm;
	private int FBHandout;
	private int FBHwSwNtwk;
	private String comments;
	private String suggestions;
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantID() {
		return participantID;
	}
	public void setParticipantID(int participantID) {
		this.participantID = participantID;
	}
	public int getFBPrsComm() {
		return FBPrsComm;
	}
	public void setFBPrsComm(int fBPrsComm) {
		FBPrsComm = fBPrsComm;
	}
	public int getFBClrfyDbts() {
		return FBClrfyDbts;
	}
	public void setFBClrfyDbts(int fBClrfyDbts) {
		FBClrfyDbts = fBClrfyDbts;
	}
	public int getFBTm() {
		return FBTm;
	}
	public void setFBTm(int fBTm) {
		FBTm = fBTm;
	}
	public int getFBHandout() {
		return FBHandout;
	}
	public void setFBHandout(int fBHandout) {
		FBHandout = fBHandout;
	}
	public int getFBHwSwNtwk() {
		return FBHwSwNtwk;
	}
	public void setFBHwSwNtwk(int fBHwSwNtwk) {
		FBHwSwNtwk = fBHwSwNtwk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}	
	
	
}
