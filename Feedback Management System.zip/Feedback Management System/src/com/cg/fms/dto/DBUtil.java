package com.cg.fms.dto;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: DBUtil class
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {

	public static Connection getConn() throws ClassNotFoundException, SQLException{
		
		final String driver = "oracle.jdbc.OracleDriver";
		final String url ="jdbc:oracle:thin:@10.219.34.3:1521:orcl";		
		final String user="trg221";
		final String password="training221";
		Connection conn=null;
		
		Class.forName(driver);
		
			try {
				conn = DriverManager.getConnection(url,user,password);
			} catch (SQLException e) {				
				e.printStackTrace();				
			}
			
		
		return conn;
		
		
	}
}
