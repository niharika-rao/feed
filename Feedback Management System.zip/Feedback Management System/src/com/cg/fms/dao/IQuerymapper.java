package com.cg.fms.dao;

public interface IQuerymapper {

	static String emp_detail = "Select * from employee_master where Employee_ID = ?";
	static String training_Part_Query = "select Training_Code from training_participant_enroll where Participant_ID =?";
	static String feedback_entry = "insert into FEEDBACK_MASTER values(?,?,?,?,?,?,?,?,?,?)";
	static String faculty_maintenance = "create view faculty_maintenance as select  tp.faculty_code,fs.skill_set, tp.course_code, cm.course_name, cm.no_of_days from training_program tp, course_master cm, faculty_skill fs where tp.course_code=cm.course_id and tp.faculty_code=fs.faculty_id";
	static String faculty_view = "select * from faculty_maintenance";
	static String course_maintenance = "select * from course_master";
	static String training_maintenance = "select tp.training_code,tp.course_code,cm.course_name,tp.faculty_code,tp.start_date,tp.end_date from training_program tp, course_master cm where tp.course_code=cm.course_id";
	static String add_course = "insert into course_master values(COURSEID_SEQ.NEXTVAL,?,?)";
	static String course_list = "Select course_id, course_name from course_master";
	static String delete_course = "delete from course_master where course_id=?";
	static String participant_enroll = "insert into training_participant_enroll values(?,?)";
	static String faculty_list = "select * from faculty_skill";
	static String training_list = "select tp.training_code, cm.course_id, cm.course_name from training_program tp, course_master cm where tp.course_code=cm.course_id";
	static String delete_training = "delete from training_program where training_code=?";
	static String participant_list = "select employee_id from employee_master where role='Participant'";
	static String training_feedback = "select distinct fm.entry_date,fm.training_code,em.employeeName,fm.FB_Presentation_Communication,fm.FB_Clarify_Doubts,fm.FB_Time_Management,fm.FB_Handout,fm.FB_HW_SW_Network from feedback_master fm, employee_master em, training_program tp where em.employeeName in (select em.employeeName from employee_master em, training_program tp, feedback_master fm where em.employee_id=tp.faculty_code and tp.training_code=fm.training_code) and (extract(month from fm.entry_date))=? and fm.training_code=tp.training_code and em.employee_id=tp.faculty_code order by fm.training_code";
	static String monthlyAverage = "select (avg(fb_presentation_communication)+avg(fb_clarify_doubts)+avg(fb_time_management)+avg(fb_handout)+avg(fb_hw_sw_network))/5 from feedback_master where (extract(month from entry_date))=?";
	static String general_feedback = "select fm.entry_date,fm.training_code,fm.participant_id,em.employeeName,fm.FB_Presentation_Communication,fm.FB_Clarify_Doubts,fm.FB_Time_Management,fm.FB_Handout,fm.FB_HW_SW_Network from feedback_master fm, employee_master em,training_program tp where em.employeeName in (select em.employeeName from training_program tp, employee_master em where tp.faculty_code=em.employee_id ) and fm.training_code=tp.training_code and em.employee_id=tp.faculty_code";
	static String addTraining = "insert into training_program values (TRAINING_CODE_SEQ.NEXTVAL, ?, ?, to_date(?,'DD/MM/YYYY'),to_date(?,'DD/MM/YYYY'))";
	
	
		}
