package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import com.cg.fms.bean.Feedback;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

public class FeedbackDAOImpl implements IFeedbackDAO {

	@Override
	public int viewFeedback() throws FMSException {
		
		ArrayList<Feedback> listOfFeedback = new ArrayList<>();
		
		int choice = 0;
		PreparedStatement pstmt;
		ResultSet rs;
		Scanner in = new Scanner(System.in);

		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
		
		do{
		System.out.println("*** FEEDBACK REPORT ***");
		System.out.println();
		System.out.println("1) Traning Feedback Report for month");
		System.out.println("2) Faculty Feedback Report for month");
		System.out.println("3) General Feedback Report");
		System.out.println("4) Exit");
		
		choice = in.nextInt();
		
		switch(choice){
		case 1: System.out.println();
				System.out.println("*** MONTHLY TRAINING PROGRAM FEEDBACK ***");
				System.out.println("-----------------------------------------");
				
				String training_feedback = "select fm.training_code, fm.participant_id, em.employeeName,fm.fb_presentation_communication,fm.fb_clarify_doubts,fm.fb_time_management,fm.fb_handout,fm.fb_hw_sw_network from feedback_master fm, employee_master em where em.employeeName in (select em.employeeName from training_program tp, employee_master em where tp.faculty_code=em.employee_id )";
			try {
				pstmt = conn.prepareStatement(training_feedback);
				rs = pstmt.executeQuery();
				System.out.println("printing...");
				while(rs.next()){
					
					int trainingCode = rs.getInt(1);
					
					//Get Al Details
					
					Feedback feedbackOutput = new Feedback();
					feedbackOutput.setTrainingCode(trainingCode);
					feedbackOutput.setTrainingCode(trainingCode);
					feedbackOutput.setTrainingCode(trainingCode);
					feedbackOutput.setTrainingCode(trainingCode);
					
					
					listOfFeedback.add(feedbackOutput);
					//Simiarly
					
					System.out.println(rs.getInt(1)+rs.getInt(2)+rs.getString(3)+rs.getInt(4)+rs.getInt(5)+rs.getInt(6)+rs.getInt(7)+rs.getInt(8));
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		default: System.out.println("wrong");
				
		
		}
		
		}while(choice>0 && choice<5);
		
		
		return 0;
	}

}
