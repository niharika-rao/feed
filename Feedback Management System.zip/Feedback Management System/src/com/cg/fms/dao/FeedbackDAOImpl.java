package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.bean.Feedback;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

public class FeedbackDAOImpl implements IFeedbackDAO {


	int trainingCode;
	int participantID;
	int fbPrsComm;
	int fbClrfyDbts;
	int fbTm;
	int fbHandout;
	int fbHwSwNtwk;
	String comments;
	String suggestions;
	Date entryDate;
	
	String employeeName;
	int facultyCode;
	
	@Override
	public ArrayList<Feedback> viewTrainingProgramReport(int month) throws FMSException{
		
		PreparedStatement pstmt;
		ResultSet rs;

		ArrayList<Feedback> feedbackList = new ArrayList<>();
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}			
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.training_feedback);
			pstmt.setInt(1, month);
			
			rs = pstmt.executeQuery();
			
			
			while(rs.next()){
				entryDate = rs.getDate(1);
				trainingCode = rs.getInt(2);
				employeeName = rs.getString(3);				
				fbPrsComm = rs.getInt(4);
				fbClrfyDbts = rs.getInt(5);
				fbTm = rs.getInt(6);
				fbHandout = rs.getInt(7);
				fbHwSwNtwk = rs.getInt(8);	
				
				Feedback feedback = new Feedback();
				
				feedback.setEntryDate(entryDate);
				feedback.setTrainingCode(trainingCode);
				feedback.setEmployeeName(employeeName);
				feedback.setFbPrsComm(fbPrsComm);
				feedback.setFbClrfyDbts(fbClrfyDbts);
				feedback.setFbTm(fbTm);
				feedback.setFbHandout(fbHandout);
				feedback.setFbHwSwNtwk(fbHwSwNtwk);
				
				feedbackList.add(feedback);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return feedbackList;
	}

	

	@Override
	public float findMonthlyAverage(int month) throws FMSException {
		
		PreparedStatement pstmt;
		ResultSet rs;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
		
		
		float avg;
		try {
			pstmt = conn.prepareStatement(IQuerymapper.monthlyAverage);
			pstmt.setInt(1, month);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
			avg = ((Number) rs.getObject(1)).floatValue();
			return avg;
			}			
		} catch (SQLException e) {
			throw new FMSException("Could not complete the action");
		}
		return 0;
	}
	
	@Override
	public ArrayList<Feedback> viewGeneralFeedback() throws FMSException {
		PreparedStatement pstmt;
		ResultSet rs;

		ArrayList<Feedback> feedbackList = new ArrayList<>();
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not connect to the driver");
		} catch (SQLException e1) {
			throw new FMSException("Could not establish connection");
		}		
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.general_feedback);		
			
			rs = pstmt.executeQuery();
						
			while(rs.next()){
				entryDate = rs.getDate(1);
				trainingCode = rs.getInt(2);
				participantID = rs.getInt(3);
				employeeName = rs.getString(4);				
				fbPrsComm = rs.getInt(5);
				fbClrfyDbts = rs.getInt(6);
				fbTm = rs.getInt(7);
				fbHandout = rs.getInt(8);
				fbHwSwNtwk = rs.getInt(9);	
				
				Feedback feedback = new Feedback();
				
				feedback.setEntryDate(entryDate);
				feedback.setTrainingCode(trainingCode);
				feedback.setParticipantID(participantID);
				feedback.setEmployeeName(employeeName);
				feedback.setFbPrsComm(fbPrsComm);
				feedback.setFbClrfyDbts(fbClrfyDbts);
				feedback.setFbTm(fbTm);
				feedback.setFbHandout(fbHandout);
				feedback.setFbHwSwNtwk(fbHwSwNtwk);
				
				feedbackList.add(feedback);
			}			
		} catch (SQLException e) {
			throw new FMSException("Could not execute the action");
		}
		return feedbackList;
	}

	@Override
	public ArrayList<Feedback> viewFacultyProgramReport(int month) throws FMSException {
		
		Connection conn = null;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not connect to the driver");
		} catch (SQLException e1) {
			throw new FMSException("Could not establish a connection");
		}	
		ArrayList<Feedback> facultyFeedbackList = new ArrayList<>();
		
		ResultSet resultSet, feedbackResultSet;
		String facultyNameQuery = "select employee_id, employeeName from employee_master where role='Faculty'";
		String facultyFeedback = "select fm.entry_date,fm.training_code,fm.FB_Presentation_Communication,fm.FB_Clarify_Doubts,fm.FB_Time_Management,fm.FB_Handout,fm.FB_HW_SW_Network from feedback_master fm, training_program tp where fm.training_code=tp.training_code and tp.faculty_code=? and (extract(month from fm.entry_date))=?";
		
		PreparedStatement pstmt, feedbackPstmt;
		
		try {
			pstmt = conn.prepareStatement(facultyNameQuery);
			resultSet = pstmt.executeQuery();
			
			while(resultSet.next()){
				facultyCode = resultSet.getInt(1);
				employeeName = resultSet.getString(2);
				
				feedbackPstmt = conn.prepareStatement(facultyFeedback);
				feedbackPstmt.setInt(1, facultyCode);
				feedbackPstmt.setInt(2, month);
				feedbackResultSet = feedbackPstmt.executeQuery();
				
				while(feedbackResultSet.next()){
					entryDate = feedbackResultSet.getDate(1);
					trainingCode = feedbackResultSet.getInt(2);					
					fbPrsComm = feedbackResultSet.getInt(3);
					fbClrfyDbts = feedbackResultSet.getInt(4);
					fbTm = feedbackResultSet.getInt(5);
					fbHandout = feedbackResultSet.getInt(6);
					fbHwSwNtwk = feedbackResultSet.getInt(7);
					
					Feedback feedback = new Feedback();
					
					feedback.setEntryDate(entryDate);
					feedback.setTrainingCode(trainingCode);
					feedback.setFbPrsComm(fbPrsComm);
					feedback.setFbClrfyDbts(fbClrfyDbts);
					feedback.setFbTm(fbTm);
					feedback.setFbHandout(fbHandout);
					feedback.setFbHwSwNtwk(fbHwSwNtwk);
					
					facultyFeedbackList.add(feedback);
					
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return facultyFeedbackList;
	}

}
