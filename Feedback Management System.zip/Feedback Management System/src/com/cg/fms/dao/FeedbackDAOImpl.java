package com.cg.fms.dao;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Feedback DAO implementation. Contains report generation methods
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.fms.bean.Feedback;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

/* this class is to display all the feedback reports to the admin and the coordinator*/
public class FeedbackDAOImpl implements IFeedbackDAO {

	Logger log = Logger.getRootLogger();
	
	int trainingCode;
	int participantID;
	int fbPrsComm;
	int fbClrfyDbts;
	int fbTm;
	int fbHandout;
	int fbHwSwNtwk;
	String comments;
	String suggestions;
	Date entryDate;
	
	String employeeName;
	int facultyCode;
	
	/*to retrieve the feedback given for a particular month. This includes the feedback
	given to all the faculties in a particular month*/
	@Override
	public ArrayList<Feedback> viewTrainingProgramReport(int month) throws FMSException{
		
		PreparedStatement pstmt;
		ResultSet rs;

		ArrayList<Feedback> feedbackList = new ArrayList<>();
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}			
		
		try {
			log.info("Executing training feedback query");
			//the feedback details with the faculty name provided for a particular month is retrieved
			pstmt = conn.prepareStatement(IQuerymapper.training_feedback);
			pstmt.setInt(1, month);
			
			rs = pstmt.executeQuery();			
			
			while(rs.next()){
				entryDate = rs.getDate(1);
				trainingCode = rs.getInt(2);
				employeeName = rs.getString(3);				
				fbPrsComm = rs.getInt(4);
				fbClrfyDbts = rs.getInt(5);
				fbTm = rs.getInt(6);
				fbHandout = rs.getInt(7);
				fbHwSwNtwk = rs.getInt(8);	
				
				Feedback feedback = new Feedback();
				
				feedback.setEntryDate(entryDate);
				feedback.setTrainingCode(trainingCode);
				feedback.setEmployeeName(employeeName);
				feedback.setFbPrsComm(fbPrsComm);
				feedback.setFbClrfyDbts(fbClrfyDbts);
				feedback.setFbTm(fbTm);
				feedback.setFbHandout(fbHandout);
				feedback.setFbHwSwNtwk(fbHwSwNtwk);
				
				//the obtained feedback object is then stored in an array list and sent back
				feedbackList.add(feedback);
			}		
		} catch (SQLException e) {
			log.info("Could not execute view training program");
			throw new FMSException("Could not execute action");
		}		
		return feedbackList;
	}

	@Override
	public float findMonthlyAverage(int month) throws FMSException {
		
		PreparedStatement pstmt;
		ResultSet rs;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not connect to driver");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
		
		float avg;
		try {
			//the average of the feedback for the month chosen is calculated
			pstmt = conn.prepareStatement(IQuerymapper.monthlyAverage);
			pstmt.setInt(1, month);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
			//the floating point value of the average is retrieved
			avg = ((Number) rs.getObject(1)).floatValue();
			return avg;
			}			
		} catch (SQLException e) {
			log.info("Could not execute monthly average calculation");
			throw new FMSException("Could not complete the action");
		}
		return 0;
	}
	
	@Override
	public ArrayList<Feedback> viewGeneralFeedback() throws FMSException {
		PreparedStatement pstmt;
		ResultSet rs;

		ArrayList<Feedback> feedbackList = new ArrayList<>();
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not connect to the driver");
		} catch (SQLException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not establish connection");
		}		
		
		try {
			//the feedback details entered in every month and for every faculty is displayed
			pstmt = conn.prepareStatement(IQuerymapper.general_feedback);		
			
			rs = pstmt.executeQuery();
						
			while(rs.next()){
				entryDate = rs.getDate(1);
				trainingCode = rs.getInt(2);
				participantID = rs.getInt(3);
				employeeName = rs.getString(4);				
				fbPrsComm = rs.getInt(5);
				fbClrfyDbts = rs.getInt(6);
				fbTm = rs.getInt(7);
				fbHandout = rs.getInt(8);
				fbHwSwNtwk = rs.getInt(9);	
				
				Feedback feedback = new Feedback();
				
				feedback.setEntryDate(entryDate);
				feedback.setTrainingCode(trainingCode);
				feedback.setParticipantID(participantID);
				feedback.setEmployeeName(employeeName);
				feedback.setFbPrsComm(fbPrsComm);
				feedback.setFbClrfyDbts(fbClrfyDbts);
				feedback.setFbTm(fbTm);
				feedback.setFbHandout(fbHandout);
				feedback.setFbHwSwNtwk(fbHwSwNtwk);
				
				feedbackList.add(feedback);
			}			
		} catch (SQLException e) {
			log.info("Could not execute general feedback report action");
			throw new FMSException("Could not execute the action");
		}
		return feedbackList;
	}

	@Override
	
	public ArrayList<Feedback> viewFacultyProgramReport(int month, int facultyID) throws FMSException {
		
		Connection conn = null;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not connect to the driver");
		} catch (SQLException e1) {
			throw new FMSException("Could not establish a connection");
		}	
		ArrayList<Feedback> facultyFeedbackList = new ArrayList<>();
		
		ResultSet feedbackResultSet;
			
		PreparedStatement  feedbackPstmt;
		
		try {		
				
				feedbackPstmt = conn.prepareStatement(IQuerymapper.facultyFeedback);
				feedbackPstmt.setInt(1, facultyID);
				feedbackPstmt.setInt(2, month);
				feedbackResultSet = feedbackPstmt.executeQuery();
				
				while(feedbackResultSet.next()){
					entryDate = feedbackResultSet.getDate(1);
					trainingCode = feedbackResultSet.getInt(2);					
					fbPrsComm = feedbackResultSet.getInt(3);
					fbClrfyDbts = feedbackResultSet.getInt(4);
					fbTm = feedbackResultSet.getInt(5);
					fbHandout = feedbackResultSet.getInt(6);
					fbHwSwNtwk = feedbackResultSet.getInt(7);
					
					Feedback feedback = new Feedback();
					
					feedback.setEntryDate(entryDate);
					feedback.setTrainingCode(trainingCode);
					feedback.setFbPrsComm(fbPrsComm);
					feedback.setFbClrfyDbts(fbClrfyDbts);
					feedback.setFbTm(fbTm);
					feedback.setFbHandout(fbHandout);
					feedback.setFbHwSwNtwk(fbHwSwNtwk);
					
					facultyFeedbackList.add(feedback);					
				}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return facultyFeedbackList;
	}


	//to check if the month entered by the user exists in the database
	@Override
	public boolean checkIfMonthExists(int month) throws FMSException {
		
		PreparedStatement pstmt;
		Connection conn = null;
		ResultSet rs;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not connect to the driver");
		} catch (SQLException e1) {
			throw new FMSException("Could not establish a connection");
		}			
		try {
			//the month is extracted from the entry date from the feedback master table
			pstmt = conn.prepareStatement(IQuerymapper.checkIfMonthExists);
			rs = pstmt.executeQuery();
			
			//with every value retrieved from the table it checks if it matches with the month entered
			while(rs.next()){
				if(rs.getInt(1) == month){
					return true;
				}
			}
			return false;
		
		} catch (SQLException e) {
			log.info("Could not execute check if month exists");
			throw new FMSException("Could not execute the action");
			}
	}

	//to display list of months for which feedback was provided
	@Override
	public ArrayList<Feedback> getMonthsFromFeedbackList() throws FMSException {

		PreparedStatement pstmt;
		ResultSet rs;

		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not create connection");
		}
		
		ArrayList<Feedback> monthList = new ArrayList<>();
		try {
			pstmt = conn.prepareStatement(IQuerymapper.checkIfMonthExists);
			rs = pstmt.executeQuery();			
			while(rs.next()){
				int month = rs.getInt(1);
				
				Feedback feedback = new Feedback();
				
				feedback.setMonth(month);
				
				monthList.add(feedback);
			}
			
		} catch (SQLException e) {
			log.info("Could not execute check if month exists");
			throw new FMSException("Could not execute check if month exists");
		}			
		return monthList;
	}

	@Override
	public boolean checkFacultyID(int facultyID) throws FMSException {
		Connection conn;
		PreparedStatement pstmt;
		ResultSet rs;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not connect to driver");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}		
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.checkIfFacultyIdExists);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				if(rs.getInt(1) == facultyID){
					return true;
				}
			}		
			
		} catch (SQLException e) {
			log.info("Could not execute checkiffacultycodeexists");
			throw new FMSException("Could not execute query");
		}
		
		return false;
	}

	@Override
	public ArrayList<Feedback> getFacultyList() throws FMSException {

		int facultyID;
		Connection conn;
		PreparedStatement pstmt;
		ResultSet rs;
		
		ArrayList<Feedback> facultyIDList = new ArrayList<>();
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not connect to driver");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}		
		
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.getFacultyId);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				facultyID = rs.getInt(1);
				
				Feedback feedback = new Feedback();
				
				feedback.setFacultyID(facultyID);
				
				facultyIDList.add(feedback);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return facultyIDList;
	}

	@Override
	public float findFacultyMonthlyAverage(int month, int facultyID) throws FMSException {
		PreparedStatement pstmt;
		ResultSet rs;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not connect to driver");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
		
		float avg;
		try {
			//the average of the feedback for the month chosen is calculated
			
			pstmt = conn.prepareStatement(IQuerymapper.monthlyFacultyAverage);
			pstmt.setInt(1, facultyID);
			pstmt.setInt(2, month);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
			//the floating point value of the average is retrieved
			avg = ((Number) rs.getObject(1)).floatValue();
			return avg;
			}			
		} catch (SQLException e) {
			log.info("Could not execute monthly average calculation");
			throw new FMSException("Could not complete the action");
		}
		return 0;
	}
	
	

}
