package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.bean.Feedback;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

public class FeedbackDAOImpl implements IFeedbackDAO {


	int trainingCode;
	int participantID;
	int fbPrsComm;
	int fbClrfyDbts;
	int fbTm;
	int fbHandout;
	int fbHwSwNtwk;
	String comments;
	String suggestions;
	Date entryDate;
	
	String employeeName;
	
	
	@Override
	public ArrayList<Feedback> viewTrainingProgramReport(int month) throws FMSException{
		
		PreparedStatement pstmt;
		ResultSet rs;

		ArrayList<Feedback> feedbackList = new ArrayList<>();
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
		
		String training_feedback = "select fm.entry_date,fm.training_code,em.employeeName,fm.FB_Presentation_Communication,fm.FB_Clarify_Doubts,fm.FB_Time_Management,fm.FB_Handout,fm.FB_HW_SW_Network from feedback_master fm, employee_master em where em.employeeName in (select em.employeeName from training_program tp, employee_master em where tp.faculty_code=em.employee_id ) and (extract(month from fm.entry_date))=?";
		
		try {
			pstmt = conn.prepareStatement(training_feedback);
			pstmt.setInt(1, month);
			
			rs = pstmt.executeQuery();
			
			
			while(rs.next()){
				entryDate = rs.getDate(1);
				trainingCode = rs.getInt(2);
				employeeName = rs.getString(3);				
				fbPrsComm = rs.getInt(4);
				fbClrfyDbts = rs.getInt(5);
				fbTm = rs.getInt(6);
				fbHandout = rs.getInt(7);
				fbHwSwNtwk = rs.getInt(8);	
				
				Feedback feedback = new Feedback();
				
				feedback.setEntryDate(entryDate);
				feedback.setTrainingCode(trainingCode);
				feedback.setEmployeeName(employeeName);
				feedback.setFbPrsComm(fbPrsComm);
				feedback.setFbClrfyDbts(fbClrfyDbts);
				feedback.setFbTm(fbTm);
				feedback.setFbHandout(fbHandout);
				feedback.setFbHwSwNtwk(fbHwSwNtwk);
				
				feedbackList.add(feedback);
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return feedbackList;
	}

	

	@Override
	public int findMonthlyAverage(int month) throws FMSException {
		
		PreparedStatement pstmt;
		ResultSet rs;
		
		Connection conn = null;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}	
		
		String monthlyAverage = "select (avg(fb_presentation_communication)+avg(fb_clarify_doubts)+avg(fb_time_management)+avg(fb_handout)+avg(fb_hw_sw_network))/5 from feedback_master where (extract(month from entry_date))=?";
		int avg;
		try {
			pstmt = conn.prepareStatement(monthlyAverage);
			pstmt.setInt(1, month);
			
			rs = pstmt.executeQuery();
			while(rs.next()){
			avg = ((Number) rs.getObject(1)).intValue();
			return avg;
			}
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return 0;
	}

}
