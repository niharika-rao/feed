package com.cg.fms.dao;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Participamnt DAO interface
 */
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.Feedback;
import com.cg.fms.exception.FMSException;

public interface IParticipantDAO {

	int provideFeedback(Employee employee, Feedback feed) throws FMSException;

}
