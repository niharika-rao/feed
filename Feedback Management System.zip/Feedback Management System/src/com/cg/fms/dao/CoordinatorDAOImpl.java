package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

public class CoordinatorDAOImpl implements ICoordinatorDAO {

	int trainingCode;
	int courseCode;
	String courseName;
	int facultyCode;
	Date startDate;
	Date endDate;
	
	int employeeID;
	
	int facultyID;
	String skillSet;
	
	int courseID;
	int noOfDays;
	
	PreparedStatement pstmt,pstmt1,pstmt2;
	ResultSet rs,rs1;
	Connection conn = null;
	
	Scanner in = new Scanner(System.in);
	
	
	@Override
	public int participantEnroll(int trainingCode, int employeeID) throws FMSException{
		
		PreparedStatement training_list_pstmt;
		ResultSet rs;
		
		int stat;
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create a connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
				
		try {	
		
		pstmt2 = conn.prepareStatement(IQuerymapper.participant_enroll);
		pstmt2.setInt(1, trainingCode);
		pstmt2.setInt(2, employeeID);
		
		stat = pstmt2.executeUpdate();		
		} catch (SQLException e) {
			throw new FMSException("Could not execute the action");
		}	
		return stat;
	}

	@Override
	public ArrayList<TrainingProgram> viewTrainingList() throws FMSException {
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
			ArrayList<TrainingProgram> trainingProgramList = new ArrayList<>();
			try {
				pstmt = conn.prepareStatement(IQuerymapper.training_maintenance);
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					trainingCode = rs.getInt(1);
					courseCode = rs.getInt(2);
					courseName = rs.getString(3);
					facultyCode = rs.getInt(4);
					startDate = rs.getDate(5);
					endDate = rs.getDate(6);
					
					TrainingProgram trainingObj = new TrainingProgram();
					
					trainingObj.setTrainingCode(trainingCode);
					trainingObj.setCourseCode(courseCode);
					trainingObj.setCourseName(courseName);
					trainingObj.setFacultyCode(facultyCode);
					trainingObj.setStartDate(startDate);
					trainingObj.setEndDate(endDate);
					
					trainingProgramList.add(trainingObj);
					
				}
		
			} catch (SQLException e) {
				throw new FMSException("Could not retrieve values");
			}			
					
			return trainingProgramList;
			
	}

	@Override
	public ArrayList<CourseMaster> viewCourseList() throws FMSException {		
		
		PreparedStatement pstmt;
		ResultSet rs;
		
		ArrayList<CourseMaster> courseList = new ArrayList<>();		

		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.course_maintenance);			
			rs = pstmt.executeQuery();
			while(rs.next()){
				courseID = rs.getInt(1);
				courseName = rs.getString(2);
				noOfDays = rs.getInt(3); 
				
				CourseMaster course = new CourseMaster();
				
				course.setCourseID(courseID);
				course.setCourseName(courseName);
				course.setNoOfDays(noOfDays);
				
				courseList.add(course);				
			}
			
		} catch (SQLException e) {
			throw new FMSException("Could not execute the action");
		}
		
		return courseList;
	
	}

	@Override
	public ArrayList<FacultySkill> viewFacultyList() throws FMSException {
		
		ArrayList<FacultySkill> facultySkillList = new ArrayList<>();
		
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		
		
		try {
			pstmt1 = conn.prepareStatement(IQuerymapper.faculty_list);
			ResultSet rs1;
			rs1 = pstmt1.executeQuery();
			
			while(rs1.next()){
			facultyID = rs1.getInt(1);
			skillSet = rs1.getString(2);
			
			FacultySkill facultySkillObj = new FacultySkill();
			
			facultySkillObj.setFacultyID(facultyID);
			facultySkillObj.setSkillSet(skillSet);
			
			facultySkillList.add(facultySkillObj);
			}
		} catch (SQLException e) {
			throw new FMSException("Could not execute the action");
		}
		
		return facultySkillList;
	}

	@Override
	public ArrayList<TrainingProgram> viewTrainings() throws FMSException {
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
				
			ArrayList<TrainingProgram> trainingList = new ArrayList<>();
			try {
				pstmt = conn.prepareStatement(IQuerymapper.training_list);
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					trainingCode = rs.getInt(1);
					courseID = rs.getInt(2);
					courseName = rs.getString(3);
					
					TrainingProgram trainingObj = new TrainingProgram();					
					trainingObj.setTrainingCode(trainingCode);	
					trainingObj.setCourseCode(courseID);
					trainingObj.setCourseName(courseName);
					trainingList.add(trainingObj);				
				}
		
			} catch (SQLException e) {
				throw new FMSException("Could not retrieve values");
			}			
					
			return trainingList;

	}

	@Override
	public int deleteTraining(TrainingProgram training) throws FMSException {
				
		int stat=0;
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		trainingCode = training.getTrainingCode();
				
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.delete_training);
			pstmt.setInt(1, trainingCode);
			stat = pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new FMSException("Could not execute the action");
		}
		return stat;
	}

	@Override
	public ArrayList<Employee> viewParticipantList() throws FMSException {

		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		ArrayList<Employee> participantList = new ArrayList<>();
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.participant_list);
			rs = pstmt.executeQuery();
			while(rs.next()){
				employeeID = rs.getInt(1);
				
				Employee employee = new Employee();
				
				employee.setEmployeeID(employeeID);
				
				participantList.add(employee);
			}
		} catch (SQLException e) {
			throw new FMSException("Could not execute the query");
		}
		return participantList;
	}

	@Override
	public int addNewTraining(int courseID, int facultyID) throws FMSException {

		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		
		
		return 0;
	}
}


