package com.cg.fms.dao;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Coordinator DAO implementation. Contains coordinator related methods
 */
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

public class CoordinatorDAOImpl implements ICoordinatorDAO {

	int trainingCode;
	int courseCode;
	String courseName;
	int facultyCode;
		
	int employeeID;
	
	int facultyID;
	String skillSet;
	
	int courseID;
	int noOfDays;	
	
	Date startDate;
	Date endDate;
	
	String startDateStr;
	String endDateStr;
	
	PreparedStatement pstmt,pstmt1,pstmt2;
	ResultSet rs,rs1;
	Connection conn = null;
	
	Logger log = Logger.getRootLogger();
	
   @Override
   //this is to enroll the participant to a training by entering the training code and participant ID
	public int participantEnroll(int trainingCode, int employeeID) throws FMSException{
			
	  log.info("In participant enroll");
		int stat;
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create a connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
				
		try {			
		pstmt2 = conn.prepareStatement(IQuerymapper.participant_enroll);
		//the training code and employee id is set to enroll the participant
		pstmt2.setInt(1, trainingCode);
		pstmt2.setInt(2, employeeID);		
		stat = pstmt2.executeUpdate();		
		
		} catch (SQLException e) {
			log.info("Exception while executing participant enroll");
			throw new FMSException("Could not execute the action");
		}	
		log.info("Successfully enrolled the participant to a training");
		return stat;
	}

   /*this function displays the available training list including trainingcode,coursecode,
   coursename,faculty code,start date and end date*/
	@Override
	public ArrayList<TrainingProgram> viewTrainingList() throws FMSException {
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
			ArrayList<TrainingProgram> trainingProgramList = new ArrayList<>();
			try {
				pstmt = conn.prepareStatement(IQuerymapper.training_maintenance);
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					trainingCode = rs.getInt(1);
					courseCode = rs.getInt(2);
					courseName = rs.getString(3);
					facultyCode = rs.getInt(4);
					startDate = rs.getDate(5);
					endDate = rs.getDate(6);
					
					TrainingProgram trainingObj = new TrainingProgram();
					
					trainingObj.setTrainingCode(trainingCode);
					trainingObj.setCourseCode(courseCode);
					trainingObj.setCourseName(courseName);
					trainingObj.setFacultyCode(facultyCode);
					trainingObj.setStartDate(startDate);
					trainingObj.setEndDate(endDate);
					
					trainingProgramList.add(trainingObj);
					
				}
		
			} catch (SQLException e) {
				throw new FMSException("Could not retrieve values");
			}			
			log.info("Displaying training list");		
			return trainingProgramList;
			
	}

	//this function displays the courseid, name and duration of the course
	@Override
	public ArrayList<CourseMaster> viewCourseList() throws FMSException {		
		
		PreparedStatement pstmt;
		ResultSet rs;
		
		ArrayList<CourseMaster> courseList = new ArrayList<>();		

		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		try {
			log.info("Executing course maintenance query");
			pstmt = conn.prepareStatement(IQuerymapper.course_maintenance);			
			rs = pstmt.executeQuery();
			while(rs.next()){
				courseID = rs.getInt(1);
				courseName = rs.getString(2);
				noOfDays = rs.getInt(3); 
				
				CourseMaster course = new CourseMaster();
				
				course.setCourseID(courseID);
				course.setCourseName(courseName);
				course.setNoOfDays(noOfDays);
				
				courseList.add(course);				
			}
			
		} catch (SQLException e) {
			log.info("Exception in executing course maintenance");
			throw new FMSException("Could not execute the action");
		}
		log.info("Successfully returned course list");
		return courseList;
	
	}

	//the facultyID and their corresponding skill sets are returned in this
	@Override
	public ArrayList<FacultySkill> viewFacultyList() throws FMSException {
		
		ArrayList<FacultySkill> facultySkillList = new ArrayList<>();
		
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}	
		
		try {
			log.info("Executing faculty skill maintenannce query");
			pstmt1 = conn.prepareStatement(IQuerymapper.faculty_list);
			ResultSet rs1;
			rs1 = pstmt1.executeQuery();
			
			while(rs1.next()){
			facultyID = rs1.getInt(1);
			skillSet = rs1.getString(2);
			
			FacultySkill facultySkillObj = new FacultySkill();
			
			facultySkillObj.setFacultyID(facultyID);
			facultySkillObj.setSkillSet(skillSet);
			
			facultySkillList.add(facultySkillObj);
			}
		} catch (SQLException e) {
			log.info("Exception in executing faculty skill maintenance display");
			throw new FMSException("Could not execute the action");
		}
		log.info("Succesfully displayed faculty skill list");
		return facultySkillList;
	}

	//displays training list by training code,course id and course name
	@Override
	public ArrayList<TrainingProgram> viewTrainings() throws FMSException {
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not connect to the driver");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
				
			ArrayList<TrainingProgram> trainingList = new ArrayList<>();
			try {
				pstmt = conn.prepareStatement(IQuerymapper.training_list);
				rs = pstmt.executeQuery();
				
				while(rs.next()){
					trainingCode = rs.getInt(1);
					courseID = rs.getInt(2);
					courseName = rs.getString(3);
					
					TrainingProgram trainingObj = new TrainingProgram();					
					trainingObj.setTrainingCode(trainingCode);	
					trainingObj.setCourseCode(courseID);
					trainingObj.setCourseName(courseName);
					trainingList.add(trainingObj);				
				}
		
			} catch (SQLException e) {
				log.info("Could not execute training list query");
				throw new FMSException("Could not retrieve values");
			}								
			return trainingList;
			
	}

	//deletes a training with training ID
	@Override
	public int deleteTraining(TrainingProgram training) throws FMSException {
				
		int stat=0;
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		//training code so entered by the coordinator, after verification is retrieved
		trainingCode = training.getTrainingCode();
						
		try {
			pstmt = conn.prepareStatement(IQuerymapper.delete_training);
			pstmt.setInt(1, trainingCode);
			stat = pstmt.executeUpdate();
		} catch (SQLException e) {
			log.info("Could not execute delete training query");
			throw new FMSException("Could not execute the action");
		}
		log.info("Successfully deleted the training");
		return stat;
	}

	//displays a list of all the participants who are enrolled to various trainings
	@Override
	public ArrayList<Employee> viewParticipantList() throws FMSException {

		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not connect to driver");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		ArrayList<Employee> participantList = new ArrayList<>();
		
		try {
			log.info("Executing participant list query");
			pstmt = conn.prepareStatement(IQuerymapper.participant_list);
			rs = pstmt.executeQuery();
			while(rs.next()){
				employeeID = rs.getInt(1);
				
				Employee employee = new Employee();
				
				employee.setEmployeeID(employeeID);
				
				participantList.add(employee);
			}
		} catch (SQLException e) {
			log.info("Could not execute participant list query");
			throw new FMSException("Could not execute the query");
		}
		log.info("Successfully displayed participant list");
		return participantList;
	}

	// a new training is added by obtaining the course code, faculty code and start and end date
	@Override
	public int addNewTraining(TrainingProgram training) throws FMSException {
		
		int n = 0;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		courseCode = training.getCourseCode();
		facultyCode = training.getFacultyCode();
		startDateStr = training.getStartDateStr();
		endDateStr = training.getEndDateStr();
						
		try {
			pstmt = conn.prepareStatement(IQuerymapper.addTraining);
			pstmt.setInt(1, courseCode);
			pstmt.setInt(2, facultyCode);
			pstmt.setString(3, startDateStr);
			pstmt.setString(4, endDateStr);
			 n = pstmt.executeUpdate();
		} catch (SQLException e) {
			log.info("Could not execute add training query");
			throw new FMSException("Sorry. Could not complete the action");
		}		
		return n;
	}

	
	//to check if the course id entered by the coordinator exists
	@Override
	public boolean checkIfCourseIdExists(int courseID) throws FMSException {
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not connect to the driver");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
			
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.checkIfCourseIdExists);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				if(rs.getInt(1) == courseID){
					return true;
				}
			}
		} catch (SQLException e) {
			log.info("SQL exception while executing checkIfCourseIDexists");
			throw new FMSException("Could not execute the action");
		}		
		return false;
	}

	//to check if the faculty id entered by the coordinator exists in the database
	@Override
	public boolean checkFacultyID(int facultyID) throws FMSException {
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not connect to driver");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}		
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.checkIfFacultyIdExists);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				if(rs.getInt(1) == facultyID){
					return true;
				}
			}
			
			
		} catch (SQLException e) {
			log.info("Could not execute checkiffacultycodeexists");
			throw new FMSException("Could not execute query");
		}
		
		return false;
	}

	//checks is the training code enetered exists in the database
	@Override
	public boolean checkTrainingCode(int trainingCode) throws FMSException {
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			log.info("Could not get driver connection");
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}	
	
		try {
			pstmt = conn.prepareStatement(IQuerymapper.checkIfTrainingCodeExists);
			rs = pstmt.executeQuery();
			//checks every retrived training code value with the value entered by coordinator
			while(rs.next()){
				//if it matches true is returned. else false
				if(rs.getInt(1) == trainingCode){
					return true;
				}
			}
		} catch (SQLException e) {
			log.info("Could not execute if training code exists");
			throw new FMSException("Could not execute the action");
		}
		
		return false;
	}

	//checks if the entered participant id is valid and exists in database
	@Override
	public boolean checkParticipantID(int employeeID) throws FMSException {
		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}	
	
		try {
			pstmt = conn.prepareStatement(IQuerymapper.checkIfParticipantExists);
			rs = pstmt.executeQuery();
			
			while(rs.next()){
				if(rs.getInt(1) == employeeID){
					return true;
				}
			}
		} catch (SQLException e) {
			log.info("Could not execute check if participant exists");
			throw new FMSException("Could not execute the action");
		}
		
		return false;

	}
}


