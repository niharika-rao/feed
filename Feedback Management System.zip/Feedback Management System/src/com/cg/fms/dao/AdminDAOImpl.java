package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;
/*this class has all the functionalities of an admin. The admin can perform faculty skill maintenance,
 * course maintenance and view the various reports. In this class, we can view the 1)faculty maintenance
 * table 2)view courses 3)add new course 4)delete a course. 
 */
public class AdminDAOImpl implements IAdminDAO {
	PreparedStatement delete_pstmt;
	PreparedStatement pstmt1, pstmt;
	
	int courseCode;
	
	int courseID;
	String courseName;
	int noOfDays;
	
	int facultyID;
	String skillSet;	
	
	int facultyCode;
	
	@Override
	public ArrayList<FacultyMaintenance> facultyMaintenance() throws FMSException {		
		
		
		ArrayList<FacultyMaintenance> listOfFeedback = new ArrayList<>();
		ResultSet rs;
		
		//the connection is first obtained
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		try {			
			TrainingProgram tp = new TrainingProgram();
			FacultySkill fs = new FacultySkill();
			CourseMaster cm = new CourseMaster();		
			
			//all the attributes of the view faculty maintenance are retrieved and stored in local variables
			pstmt1 = conn.prepareStatement(IQuerymapper.faculty_view);			
			rs = pstmt1.executeQuery();
			while(rs.next()){
				facultyCode = rs.getInt(1);
				skillSet = rs.getString(2);
				courseCode = rs.getInt(3);
				courseName = rs.getString(4);
				noOfDays = rs.getInt(5);
				
				FacultyMaintenance maintenance = new FacultyMaintenance(); 
				//the obtained values are then set in the bean class
				
				maintenance.setFacultyCode(facultyCode);
				maintenance.setSkillSet(skillSet);
				maintenance.setCourseCode(courseCode);
				maintenance.setCourseName(courseName);
				maintenance.setNoOfDays(noOfDays);
				
				//the object is then added to the list which is returned back
				listOfFeedback.add(maintenance);		
			}						
		} catch (SQLException e) {
			throw new FMSException("Could not execute the action");
		}
		return listOfFeedback;	
		
	}

	@Override
	public ArrayList<CourseMaster> viewCourse() throws FMSException {
				
		PreparedStatement pstmt;
		ResultSet rs;
		
		ArrayList<CourseMaster> courseList = new ArrayList<>();		

		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		try {
			//all the rows from the course_master table are retrieved
			pstmt = conn.prepareStatement(IQuerymapper.course_maintenance);			
			rs = pstmt.executeQuery();
			while(rs.next()){
				courseID = rs.getInt(1);
				courseName = rs.getString(2);
				noOfDays = rs.getInt(3); 
				
				CourseMaster course = new CourseMaster();
				
				course.setCourseID(courseID);
				course.setCourseName(courseName);
				course.setNoOfDays(noOfDays);
				
				//an arrayList containing the course_master table's object is returned back
				courseList.add(course);
			}
			
		} catch (SQLException e) {
			throw new FMSException("Could not execute the action");
		}
		
		return courseList;
	}



	@Override
	public int addNewCourse(CourseMaster course) throws FMSException {
		
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		courseName = course.getCourseName();
		noOfDays = course.getNoOfDays();
		
		int n;
		try {
			//A new course is added to the course_master table by entering the course name and duration of the course. A new course id is generated automatically
			pstmt = conn.prepareStatement(IQuerymapper.add_course);
			
			pstmt.setString(1, courseName);
			pstmt.setInt(2, noOfDays);
				
			n = pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new FMSException("Had a problem while executing the query");
		}
		return n;
	}



	@Override
	public int deleteCourse(int courseID) throws FMSException {
		
		int n;
		
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			throw new FMSException("Could not create connection");
		}
		
		try {
			//the row from the course_master table will be deleted based on the courseId being passed
			delete_pstmt = conn.prepareStatement(IQuerymapper.delete_course);
			delete_pstmt.setInt(1, courseID);
			//if more than one row is returned, the deletion was a success
			n = delete_pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new FMSException("Could not execute delete_course query");
		}		
		return n;
	}

}
