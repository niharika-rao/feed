package com.cg.fms.test;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: JUnit test class for admin
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.fms.dao.AdminDAOImpl;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exception.FMSException;

public class Admin {
IAdminDAO ad=new AdminDAOImpl();
	@Test
	public void testCheckIfCourseIdExists() throws FMSException {
		assertEquals(true,ad.checkIfCourseIdExists(100));
	}
	@Test
	public void testCheckIfCourseIdExists1() throws FMSException {
		assertEquals(true,ad.checkIfCourseIdExists(101));
	}
}
