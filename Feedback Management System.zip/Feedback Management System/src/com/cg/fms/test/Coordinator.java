package com.cg.fms.test;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: JUnit test class for coordinator
 */
import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.fms.dao.CoordinatorDAOImpl;
import com.cg.fms.dao.ICoordinatorDAO;
import com.cg.fms.exception.FMSException;

public class Coordinator {

ICoordinatorDAO cor = new CoordinatorDAOImpl();
	@Test
	public void testCheckTrainingCode() throws FMSException {
		assertEquals(true,cor.checkTrainingCode(1));
	}

	@Test
	public void testCheckTrainingCode1() throws FMSException {
		assertEquals(true,cor.checkTrainingCode(2));
	}
	@Test
	public void testCheckParticipantID() throws FMSException {
		assertEquals(true,cor.checkParticipantID(10400));
	}

}
