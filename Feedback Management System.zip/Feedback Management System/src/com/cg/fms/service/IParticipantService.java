package com.cg.fms.service;

import com.cg.fms.bean.Employee;
import com.cg.fms.bean.Feedback;
import com.cg.fms.exception.FMSException;

public interface IParticipantService {

	public int provideFeedback(Employee employee, Feedback feed) throws FMSException;

	public boolean checkFeedbackValue(String str);
}
