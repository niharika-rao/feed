package com.cg.fms.service;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Feedback service interface
 */
import java.util.ArrayList;

import com.cg.fms.bean.Feedback;
import com.cg.fms.exception.FMSException;

public interface IFeedbackService {
	
	public ArrayList<Feedback> viewTrainingProgramReport(int month) throws FMSException;

	public float findMonthlyAverage(int month) throws FMSException;

	public ArrayList<Feedback> viewGeneralFeedback() throws FMSException;

	public ArrayList<Feedback> viewFacultyProgramReport(int month, int facultyID) throws FMSException;

	public boolean checkMonth(String monthStr) throws FMSException;

	public ArrayList<Feedback> getMonthsFromFeedbackList() throws FMSException;
	
	public boolean checkFacultyID(String facultyIDStr) throws FMSException;

	public ArrayList<Feedback> getFacultyList() throws FMSException;

	public float findFacultyMonthlyAverage(int month, int facultyID) throws FMSException;
}
