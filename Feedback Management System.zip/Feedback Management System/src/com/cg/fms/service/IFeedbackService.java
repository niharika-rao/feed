package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.Feedback;
import com.cg.fms.exception.FMSException;

public interface IFeedbackService {

	public ArrayList<Feedback> viewFeedback() throws FMSException;
}
