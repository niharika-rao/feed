package com.cg.fms.service;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Employee service interface
 */
import java.sql.SQLException;

import com.cg.fms.bean.Employee;
import com.cg.fms.exception.FMSException;

public interface IEmployeeService{
	
	public boolean login(Employee employee) throws FMSException, SQLException;

	public boolean validateUserID(String employeeIDStr);

	public boolean validatePassword(String password);	
	
	
}
