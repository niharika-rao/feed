package com.cg.fms.service;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Employee service class
 */
import java.sql.SQLException;
import com.cg.fms.bean.Employee;
import com.cg.fms.dao.EmployeeDAOImpl;
import com.cg.fms.dao.IEmployeeDAO;
import com.cg.fms.exception.FMSException;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDAO dao = new EmployeeDAOImpl();
	@Override
	public boolean login(Employee employee) throws FMSException, SQLException {
		
		return dao.login(employee);
	}
    /* check if the user id entered is valid*/
    public boolean validateUserID(String employeeIDStr){
    	
    	//checks if userid contains only digits. if not returns false
    	for(int i=0;i<employeeIDStr.length();i++){
			if(!Character.isDigit(employeeIDStr.charAt(i)))
				return false;
		}
    	//checks if user id has less than or more than 5 digits. returns false if so
    	if(employeeIDStr.length()!= 5)
			return false;
    	
    	//returns true if none of the conditions are false
				return true;
    }

    //validates the password entered
	@Override
	public boolean validatePassword(String password) {
		
		//if the length of the password is less than 3 chars or more than 15, returns false.
		if(password.length()<3 || password.length()>15)
			return false;
		//checks if password has only letters and digits. returns true if so
		if(password.matches("[a-zA-z0-9]+"))
			return true;
		
		//returns false when all conditions fail
		return false;
	}
    
    
}
