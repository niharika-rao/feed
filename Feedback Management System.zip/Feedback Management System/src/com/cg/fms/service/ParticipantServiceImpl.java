package com.cg.fms.service;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Participant service class. To take feedback from participants
 */
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.fms.bean.Employee;
import com.cg.fms.bean.Feedback;
import com.cg.fms.dao.IParticipantDAO;
import com.cg.fms.dao.ParticipantDAOImpl;
import com.cg.fms.exception.FMSException;

public class ParticipantServiceImpl implements IParticipantService {

	IParticipantDAO dao = new ParticipantDAOImpl();
	public int provideFeedback(Employee employee, Feedback feed) throws FMSException {
		
		 return dao.provideFeedback(employee,feed);		
	}
	/* checks if the entered feedback is a digit and ranges only between 1 and 5. Returns
	 * true if the conditions satisfy, else false*/
	@Override
	public boolean checkFeedbackValue(String str) {
		for(int i=0;i<str.length();i++){
			if(!Character.isDigit(str.charAt(i)))
				return false;
		}
		if(str.length()>1)
			return false;
		
		int feedback = Integer.parseInt(str);
		if(feedback<0 || feedback>5){
			return false;
		}
			return true;
	}
	/*validates if the message has a minimum of 10 chars and maximum of 150*/
	@Override
	public boolean checkIfValidMessage(String str) {
		
		Pattern p = Pattern.compile("[a-zA-z 0-9\\s & ,(,)]{10,150}");
		Matcher m = p.matcher(str);
		return m.matches();
	}
		
}
