package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.dao.AdminDAOImpl;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exception.FMSException;

public class AdminServiceImpl implements IAdminService{

	IAdminDAO dao = new AdminDAOImpl();
	@Override
	public ArrayList<FacultyMaintenance> facultyMaintenance() throws FMSException{
		return dao.facultyMaintenance();
		
	}
	
	public ArrayList<CourseMaster> viewCourse() throws FMSException{
		return dao.viewCourse();
	}
	
	public int addNewCourse(CourseMaster course) throws FMSException{
		return dao.addNewCourse(course);
	}

	@Override
	public int deleteCourse(int courseID) throws FMSException {
		
		return dao.deleteCourse(courseID);
	}

	@Override
	public boolean checkIfInt(String noOfDaysStr) {
		
		for(int i=0;i<noOfDaysStr.length();i++){
			if(!Character.isDigit(noOfDaysStr.charAt(i)))
				return false;
		}
				return true;
	}
	
	public boolean checkMonth(String str) {		
		for(int i=0;i<str.length();i++){
			if(!Character.isDigit(str.charAt(i)))
				return false;
		}
		int month = Integer.parseInt(str);
		if(month<0 || month>12){
			return false;
		}
			return true;
				
	}

}
