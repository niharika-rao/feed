package com.cg.fms.service;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Admin Service Implementation class
 */
import java.util.ArrayList;

import org.apache.log4j.Logger;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.dao.AdminDAOImpl;
import com.cg.fms.dao.IAdminDAO;
import com.cg.fms.exception.FMSException;

public class AdminServiceImpl implements IAdminService{

	Logger log = Logger.getRootLogger();
	
	IAdminDAO dao = new AdminDAOImpl();
	@Override
	public ArrayList<FacultyMaintenance> facultyMaintenance() throws FMSException{
		return dao.facultyMaintenance();		
	}
	
	public ArrayList<CourseMaster> viewCourse() throws FMSException{
		return dao.viewCourse();
	}
	
	public int addNewCourse(CourseMaster course) throws FMSException{
		return dao.addNewCourse(course);
	}

	@Override
	public int deleteCourse(int courseID) throws FMSException {
		
		return dao.deleteCourse(courseID);
	}

	@Override
	public boolean checkIfInt(String str) {
		
		for(int i=0;i<str.length();i++){
			if(!Character.isDigit(str.charAt(i)))
				return false;
		}
		if(str.length()>4)
			return false;
				
		return true;
	}
	
	//validation of course name
	@Override
	public boolean checkCourseName(String courseName) {
		/*checks if the course name has letters,digits,space characters and hyphen and underscore
		If it does, then it returns true else returns false*/
		if(courseName.matches("[a-zA-z0-9\\s-_]+")){
			log.info("Course name is valid");
		return true;
		}
		log.info("Course name is invalid");
		return false;
		
	}
	
	/*checks if the entered course id has only digits and if the length is not greater
	 * than 4. If so, it is then converted to an integer and sent to the dao layer to check if it
	 * exists in the database. if it does, then true is returned to the UI else false is returned*/
	public boolean checkCourseID(String courseIDStr) throws FMSException{
		for(int i=0;i<courseIDStr.length();i++){
			if(!Character.isDigit(courseIDStr.charAt(i)))
				return false;
		}
		if(courseIDStr.length()>4)
			return false;
		int courseID = Integer.parseInt(courseIDStr);
		try {
			if(dao.checkIfCourseIdExists(courseID)){
				return true;
			}
		} catch (FMSException e) {
			log.info("Could not check if course id exists");
			throw new FMSException("Could not execute the action");
		}		
		return false;
	}

	

}
