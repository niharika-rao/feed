package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.dao.CoordinatorDAOImpl;
import com.cg.fms.dao.ICoordinatorDAO;
import com.cg.fms.exception.FMSException;

public class CoordinatorServiceImpl implements ICoordinatorService {

	ICoordinatorDAO dao = new CoordinatorDAOImpl();
	
	@Override
	
	public int participantEnroll(int trainingCode, int employeeID) throws FMSException{
		return dao.participantEnroll(trainingCode, employeeID);		
	}

	@Override
	public ArrayList<TrainingProgram> viewTrainingList() throws FMSException {
		// TODO Auto-generated method stub
		return dao.viewTrainingList();
	}

	@Override
	public ArrayList<CourseMaster> viewCourseList() throws FMSException {
		
		return dao.viewCourseList();
	}

	@Override
	public ArrayList<FacultySkill> viewFacultyList() throws FMSException {
		
		return dao.viewFacultyList();
	}

	@Override
	public ArrayList<TrainingProgram> viewTrainings() throws FMSException {
		
		return dao.viewTrainings();
	}

	@Override
	public int deleteTraining(TrainingProgram training) throws FMSException {
		
		 int n = dao.deleteTraining(training);
		 return n;
	}

	@Override
	public ArrayList<Employee> viewParticipantList() throws FMSException {
		// TODO Auto-generated method stub
		return dao.viewParticipantList();
	}

	@Override
	public int addNewTraining(TrainingProgram training) throws FMSException {
		// TODO Auto-generated method stub
		return dao.addNewTraining(training);
	}

}
