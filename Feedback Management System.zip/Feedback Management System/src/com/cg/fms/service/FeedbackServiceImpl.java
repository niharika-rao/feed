package com.cg.fms.service;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Feedback service class. Common to admin and coordinator
 */
import java.util.ArrayList;

import com.cg.fms.bean.Feedback;
import com.cg.fms.dao.FeedbackDAOImpl;
import com.cg.fms.dao.IFeedbackDAO;
import com.cg.fms.exception.FMSException;


public class FeedbackServiceImpl implements IFeedbackService {

	IFeedbackDAO dao = new FeedbackDAOImpl();
	
	@Override
	public ArrayList<Feedback> viewTrainingProgramReport(int month) throws FMSException {

		return dao.viewTrainingProgramReport(month);		
	}
	@Override
	public float findMonthlyAverage(int month) throws FMSException {
		
		return dao.findMonthlyAverage(month);
	}
	@Override
	public ArrayList<Feedback> viewGeneralFeedback() throws FMSException {
		// TODO Auto-generated method stub
		return dao.viewGeneralFeedback();
	}
	@Override
	public ArrayList<Feedback> viewFacultyProgramReport(int month, int facultyID) throws FMSException {
		// TODO Auto-generated method stub
		return dao.viewFacultyProgramReport(month,facultyID);
	}
	
	/*checks if the entered month has only digits and if it's between 1 and 12. Later
	 * it checks if the entered month value exists in the database and returns true else returns false*/
	@Override
	public boolean checkMonth(String str) throws FMSException {		
		for(int i=0;i<str.length();i++){
			if(!Character.isDigit(str.charAt(i)) || Character.isWhitespace(str.charAt(i)) )
				return false;
		}
		int month = Integer.parseInt(str);
		if(month<0 || month>12){
			return false;
		}
		if(dao.checkIfMonthExists(month)){
			return true;
		}
			return false;				
	}
	
	@Override
	public ArrayList<Feedback> getMonthsFromFeedbackList() throws FMSException {
		return dao.getMonthsFromFeedbackList();
	}
	@Override
	public boolean checkFacultyID(String facultyIDStr) throws FMSException {
		
		for(int i=0;i<facultyIDStr.length();i++){
			if(!Character.isDigit(facultyIDStr.charAt(i)))
				return false;
		}
		if(facultyIDStr.length()>5)
			return false;
		
		int facultyID = Integer.parseInt(facultyIDStr);
		if(dao.checkFacultyID(facultyID)){
			return true;
		}		
		return false;
	}
	@Override
	public ArrayList<Feedback> getFacultyList() throws FMSException {
		return dao.getFacultyList();
	}
	@Override
	public float findFacultyMonthlyAverage(int month, int facultyID)
			throws FMSException {
		
		return dao.findFacultyMonthlyAverage(month, facultyID);
	}

}
