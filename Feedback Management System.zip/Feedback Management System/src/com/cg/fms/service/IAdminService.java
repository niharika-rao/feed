package com.cg.fms.service;

import com.cg.fms.exception.FMSException;

public interface IAdminService {

	public void facultyMaintenance() throws FMSException;
	public void courseMaintenance() throws FMSException;
}
