package com.cg.fms.service;

import java.util.ArrayList;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.exception.FMSException;

public interface IAdminService {

	public ArrayList<FacultyMaintenance> facultyMaintenance() throws FMSException;
	public ArrayList<CourseMaster> viewCourse() throws FMSException;
	public int addNewCourse(CourseMaster course) throws FMSException;
	public int deleteCourse(int courseID) throws FMSException;
}
