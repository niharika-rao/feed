package com.cg.fms.service;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Admin service interface
 */
import java.util.ArrayList;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.exception.FMSException;

public interface IAdminService {

	public ArrayList<FacultyMaintenance> facultyMaintenance() throws FMSException;
	public ArrayList<CourseMaster> viewCourse() throws FMSException;
	public int addNewCourse(CourseMaster course) throws FMSException;
	public int deleteCourse(int courseID) throws FMSException;
	public boolean checkIfInt(String str);
	public boolean checkCourseName(String courseName);
	public boolean checkCourseID(String courseIDStr) throws FMSException;
}
