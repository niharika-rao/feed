package com.cg.fms.exception;
/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Exception class
 */
public class FMSException extends Exception{

	private static final long serialVersionUID = 1L;

	public FMSException() {
	}
	
	public FMSException(String s) {
		super(s);
	}
}
