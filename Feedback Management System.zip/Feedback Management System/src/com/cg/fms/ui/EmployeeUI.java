package com.cg.fms.ui;

/*Project Name: Feedback Management System
 * Made by: Niharika S
 * Employee ID: 155250
 * Created on: 20/09/2018
 * Version: 1.0
 * Last Updated: 09/10/18
 * Description: Main class
 */
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.Feedback;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.AdminServiceImpl;
import com.cg.fms.service.CoordinatorServiceImpl;
import com.cg.fms.service.DateValidator;
import com.cg.fms.service.EmployeeServiceImpl;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.IAdminService;
import com.cg.fms.service.ICoordinatorService;
import com.cg.fms.service.IEmployeeService;
import com.cg.fms.service.IFeedbackService;
import com.cg.fms.service.IParticipantService;
import com.cg.fms.service.ParticipantServiceImpl;

/* In this class, the user enters his user id and password and the menu will be displayed based 
 * on the role of the user which can be admin, coordinator or a participant. The admin has the privileges
 * to maintain faculty skill and course. The coordinator has the privileges to maintain the training program
 * and participant enrollment. The participant can login and enter the feedback for the training attended*/
public class EmployeeUI {

	static String employeeIDStr;
	static int employeeID;
	static String password;
	static String role;
	
	
	public static void main(String[] args) {
		Logger log = Logger.getRootLogger();
		
		int status = 0;
		int attempt=0;
		int month;
		boolean check;
		
		String choice = null, option = null;
				
		String courseName;
		int noOfDays = 0;
		
		int courseID;
		int facultyID = 0;
		int trainingCode;
		int employeeID = 0;
	
		int fbPrsComm;
		int fbClrfyDbts;
		int fbTm;
		int fbHandout;
		int fbHwSwNtwk;
		String comments;
		String suggestions;
		
		String fbPrsCommStr;
		String fbClrfyDbtsStr;
		String fbTmStr;
		String fbHandoutStr;
		String fbHwSwNtwkStr;
		
		String startDateStr;
		String endDateStr;
		String noOfDaysStr;
		String courseIDStr;
		String trainingCodeStr;
		String monthStr;
		String facultyIDStr;	
		
		CourseMaster course = new CourseMaster();
		TrainingProgram training = new TrainingProgram();
		Feedback feed = new Feedback();
		
		Scanner scanner = new Scanner(System.in);
		BufferedReader reader =  new BufferedReader(new InputStreamReader(System.in));
		
		IEmployeeService service = new EmployeeServiceImpl();
		IAdminService admin = new AdminServiceImpl();
		ICoordinatorService coordinator = new CoordinatorServiceImpl();
		IParticipantService participant = new ParticipantServiceImpl();
		IFeedbackService feedback = new FeedbackServiceImpl();
		Employee employee = new Employee();
				
		//The user enters their employee id and password
		System.out.println("*** Feedback Management System ***");
		do{		
			if(attempt>=3){
				System.err.println("Too many invalid attempts. Please try later!");
				log.info("Tried to login with wrong credentials for more than 3 times");
				break;
			}
			System.out.println();
			System.out.println("=================LOGIN===================");
			System.out.println();
			System.out.print("Enter the Employee ID:");
			try {
			employeeIDStr = reader.readLine();			
			//the user id is checked if it has only digits and the length is 5
				if(!service.validateUserID(employeeIDStr))	
				{
					log.info("Entered wrong employee ID");
					System.out.println("Please ensure the employeeID contains 5 digits and no spaces");
					attempt++;
					continue;
				}
				employeeID = Integer.parseInt(employeeIDStr);
				System.out.print("Enter the Password: ");				
				password = reader.readLine();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			//the password can have lower case,upper case letters and digits. Minimum length is 3 and maximum is 15
				if(!service.validatePassword(password)){
					log.info("Entered wrong format of password");
					System.out.println();
					System.out.println("Please ensure your password ranges between 3-15 characters and has no spaces");
					attempt++;
					continue;
				}

		/*The entered credentials are set in the bean class and the object is sent 
		 * to the service layer which then calls the dao layer where the user is authenticated
		 */
		employee.setEmployeeID(employeeID);		
		employee.setPassword(password);
				
		try{		
		check = service.login(employee);	
		//if true is returned it means the entered userId and password is correct and the menu will be displayed accordingly
		log.info("Login successful");
		
		if(check){
		//If the role is admin, then he can choose if he wants to perform faculty skill maintenance or course maintenance
			if(employee.getRole().equalsIgnoreCase("Admin")){
			log.info("Entered admin page");
			System.out.println();
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
						
			do{
			System.out.println();
			System.out.println(" Choose the action you want to perform: ");
			System.out.println("-----------------------------------------");
			System.out.println("|                                       |");
			System.out.println("|      1) Faculty Skill Maintenance     |");
			System.out.println("|      2) Course Maintenance            |");
			System.out.println("|      3) View Feedback Report          |");
			System.out.println("|      4) Log out                       |");
			System.out.println("|                                       |");
			System.out.println("-----------------------------------------");			
			choice  = scanner.next();				
			
			//the admin is displayed a menu to choose from based on the requirement
			switch(choice){
			case "1" : 
				log.info("Admin choose Faculty skill maintenance");
				//this displays the faculty and their skills mapped to the courses they teach
				//An array list of the table is obtained and displayed here
				ArrayList<FacultyMaintenance> facultyList = admin.facultyMaintenance();	
				System.out.println("===============================");
				System.out.println("FACULTY SKILL LIST");
				System.out.println("===============================");
				System.out.println();
				System.out.format("%-20s %-40s %-20s %-25s %-20s","FACULTY CODE","SKILL SET","COURSE CODE","COURSE NAME","NO OF DAYS");
				System.out.println();
				System.out.println("-----------------------------------------------------------------------------------------------------------------------");
				for (FacultyMaintenance faculty : facultyList) 
				{
					System.out.format("%-20s %-40s %-20s %-25s %-20s",faculty.getFacultyCode(),faculty.getSkillSet(),faculty.getCourseCode(),faculty.getCourseName(),faculty.getNoOfDays());
					System.out.println();
				}
				System.out.println();
				System.out.println("-----------------------------------------------------------------------------------------------------------------------");
				break;
				
			case "2":
				log.info("Admin chose course maintenance");
				label1: do{
				//here the admin can choose between viewing, adding and deleting courses
				System.out.println();
				System.out.println("===============================");
				System.out.println("COURSE MAINTENANCE");
				System.out.println("===============================");
				System.out.println("Choose the action you want to perform");
				System.out.println("------------------------------");
				System.out.println("|                            |");
				System.out.println("|    1)View Course details   |");
				System.out.println("|    2)Add new course        |");
				System.out.println("|    3)Delete course         |");
				System.out.println("|    4)Exit                  |");
				System.out.println("|                            |");
				System.out.println("------------------------------");
				option = scanner.next();
				
				switch(option){
				case "1": 
					ArrayList<CourseMaster> courseList = admin.viewCourse();
					//here the course name along with the course id is displayed
					System.out.println("------------------------------------------------------------------------");
					System.out.format("%-20s %-25s %-20s","COURSE ID","COURSE NAME","NO OF DAYS");
					System.out.println();
					System.out.println("------------------------------------------------------------------------");
					
					for(CourseMaster courseObj: courseList){
						System.out.format("%-20s %-25s %-20s",courseObj.getCourseID(),courseObj.getCourseName(),courseObj.getNoOfDays());
						System.out.println();
					}
					System.out.println();
					System.out.println("------------------------------------------------------------------------");
					log.info("Printed course list");
					break;
				case "2":
					System.out.println();
					System.out.print("Enter the Course Name: ");
					try {
						courseName = reader.readLine();
						while(admin.checkCourseName(courseName) == false){
							log.info("Wrong course name format");
							System.out.println();
							System.out.print("Please enter a valid course name: ");							
							courseName = reader.readLine();
						}
						System.out.print("Enter the Course duration in terms of number of days: ");
						noOfDaysStr = reader.readLine();
						
						while(admin.checkIfInt(noOfDaysStr) == false){
							log.info("Wrong format of course duration");
							System.out.println();
							System.out.print("Please enter valid course duration: ");							
							noOfDaysStr = reader.readLine();
						}						
						/*To add a new course, the course name and the duration is taken from the admin and set in
						the bean class and the object is passed along to the addNewCourse method*/
						
						noOfDays = Integer.parseInt(noOfDaysStr);	
						course.setCourseName(courseName);
						course.setNoOfDays(noOfDays);
						
						int n = admin.addNewCourse(course);
						//if the number of rows returned is more than 1, then a success message is displayed
						if(n>0){
							System.out.println();
							System.out.println("You have added a new course!");
							log.info("New course was added by admin");
							break;
						}
						else{
							System.out.println("No new courses were added");
							log.info("No new courses were added");
						}
					} catch (IOException e) {
						throw new FMSException("I/O Exception");
					}
								  
					break;
					
				case "3":
					log.info("Entered delete course");
					//the course list is displayed first and the admin has to choose which course he wants to delete
					System.out.println();					
					System.out.println("Course List");				
					
					ArrayList<CourseMaster> listOfCourses = admin.viewCourse();
					System.out.format("%-20s %-25s %-20s","COURSE ID","COURSE NAME","NO OF DAYS");
					System.out.println();
					System.out.println("------------------------------------------------------------------------");
										
					for(CourseMaster courseObj: listOfCourses){
						System.out.format("%-20s %-25s %-20s",courseObj.getCourseID(),courseObj.getCourseName(),courseObj.getNoOfDays());
						System.out.println();
					}					
					System.out.println();
					System.out.println("------------------------------------------------------------------------");
					System.out.print("Enter the course ID you want to delete: ");
					courseIDStr = reader.readLine();
					
					while(admin.checkCourseID(courseIDStr) == false){
						log.info("Wrong course ID format was entered to delete");
						System.out.println();
						System.out.print("Please enter valid course ID to delete: ");						
						courseIDStr = reader.readLine();
					}
					
					courseID = Integer.parseInt(courseIDStr);					
					//the entered course id is then sent to delete from the database
					int stat = admin.deleteCourse(courseID);
					if(stat>0){
						System.out.println("You have deleted the course "+courseID);
						log.info("Course was successfully deleted");
					}
					else{
					System.out.println("No courses were deleted");
					log.info("No courses were deleted");
					}
					break;
				case "4": break label1;
				default: System.out.println("<< Please choose options from 1-4 only >>");
			   }
			}while(true);
						break;
				
			case "3" :
				log.info("Admin entered feedback report page");
				System.out.println("=====================");
				System.out.println("FEEDBACK REPORT");
				System.out.println("=====================");
				
				label2: do{	
					System.out.println();
					System.out.println("-------------------------------------------");
					System.out.println("|                                          |");
					System.out.println("|   1) Training Feedback Report for month  |");
					System.out.println("|   2) Faculty Feedback Report for month   |");
					System.out.println("|   3) General Feedback Report             |");
					System.out.println("|   4) Exit                                |");
					System.out.println("|                                          |");
					System.out.println("-------------------------------------------");
				
				String opt = scanner.next();				
								
					switch(opt){
					case "1": 
						log.info("Admin chose to view monthly feedback");
						System.out.println();
						System.out.println("=========================================");
						System.out.println("MONTHLY TRAINING PROGRAM FEEDBACK");
						System.out.println("=========================================");
						
						System.out.println("Months for which feedback is available");
						System.out.println("---------------------------------------");
						ArrayList<Feedback> monthList = feedback.getMonthsFromFeedbackList();
						for(Feedback months: monthList){
							System.out.println(months.getMonth());
						}
												
						System.out.println();
						System.out.print("Enter the month (1-12) you want to view feedback for: ");							
						monthStr = reader.readLine();
						
						while(feedback.checkMonth(monthStr) == false){
							System.out.println();
							System.out.print("Please enter valid month to view feedback: ");
							monthStr = reader.readLine();
						}					
						
						month = Integer.parseInt(monthStr);
						ArrayList<Feedback> feedbackList = feedback.viewTrainingProgramReport(month);
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%-20s %-15s %-25s %-10s %-10s %-10s %-10s %-10s","Date","Training","Faculty","Pres&COmm","ClrfyDbt","Time Mgmt","Handout","HwSwNw");
						System.out.println();
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: feedbackList){
							System.out.format("%-20s %-15s %-25s %-10s %-10s %-10s %-10s %-10s",feedbackObj.getEntryDate(),feedbackObj.getTrainingCode(),feedbackObj.getEmployeeName(),feedbackObj.getFbPrsComm(),feedbackObj.getFbClrfyDbts(),feedbackObj.getFbTm(),feedbackObj.getFbHandout(),feedbackObj.getFbHwSwNtwk());
							System.out.println();
						}
						System.out.println();
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						
						float average = feedback.findMonthlyAverage(month);
						System.out.println();
						System.out.println("Average Score: "+ average);											
						break;
						
					case "2":
						System.out.println();
						System.out.println("===========================");
						System.out.println("MONTHLY FACULTY FEEDBACK");
						System.out.println("===========================");						
						System.out.println("Months for which feedback is available");
						System.out.println("---------------------------------------");
						ArrayList<Feedback> monthsList = feedback.getMonthsFromFeedbackList();
						for(Feedback months: monthsList){
							System.out.println(months.getMonth());
						}												
						System.out.println();
						System.out.print("Enter the month (1-12) you want to view feedback for: ");							
						monthStr = reader.readLine();
						
						while(feedback.checkMonth(monthStr) == false){
							System.out.println();
							System.out.print("Please enter valid month to view feedback: ");
							monthStr = reader.readLine();
						}					
						month = Integer.parseInt(monthStr);
						
						System.out.println();
						System.out.println("Choose faculty to view feedback for");
						System.out.println("---------------------");
						
						ArrayList<Feedback> ListOfFaculty = feedback.getFacultyList();
						for(Feedback faculty: ListOfFaculty){
							System.out.println(faculty.getFacultyID());
						}
						facultyIDStr = reader.readLine();
						
						while(feedback.checkFacultyID(facultyIDStr) == false){
							System.out.println();
							System.out.println("Please enter valid faculty ID");
							facultyIDStr = reader.readLine();
						}
						facultyID = Integer.parseInt(facultyIDStr);
						
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%-15s %-15s %-10s %-10s %-10s %-10s %-10s","Date","Training","Pres&COmm","ClrfyDbt","Time Mgmt","Handout","HwSwNw");
						System.out.println();
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						ArrayList<Feedback> facultyFeedbackList = feedback.viewFacultyProgramReport(month,facultyID);
						
						for(Feedback feedbackObj: facultyFeedbackList){
							System.out.format("%-15s %-15s %-10s %-10s %-10s %-10s %-10s",feedbackObj.getEntryDate(),feedbackObj.getTrainingCode(),feedbackObj.getFbPrsComm(),feedbackObj.getFbClrfyDbts(),feedbackObj.getFbTm(),feedbackObj.getFbHandout(),feedbackObj.getFbHwSwNtwk());
							System.out.println();
						}	
						
						float avg = feedback.findFacultyMonthlyAverage(month, facultyID);
						System.out.println();
						System.out.println("Average Score: "+ avg);
						
						break;
						
					case "3": 
						log.info("Admin chose to view general feedback");
						System.out.println();
						System.out.println("=====================");
						System.out.println("GENERAL FEEDBACK");
						System.out.println("=====================");
						
						ArrayList<Feedback> generalFeedbackList = feedback.viewGeneralFeedback();
						
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%-20s %-15s %-20s %-20s %-10s %-10s %-10s %-10s %-10s","Date","Training","Participant ID","Faculty","Pres&COmm","ClrfyDbt","Time Mgmt","Handout","HwSwNw");
						System.out.println();
						System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj:  generalFeedbackList){
							System.out.format("%-20s %-15s %-20s %-20s %-10s %-10s %-10s %-10s %-10s",feedbackObj.getEntryDate(),feedbackObj.getTrainingCode(),feedbackObj.getParticipantID(),feedbackObj.getEmployeeName(),feedbackObj.getFbPrsComm(),feedbackObj.getFbClrfyDbts(),feedbackObj.getFbTm(),feedbackObj.getFbHandout(),feedbackObj.getFbHwSwNtwk());
							System.out.println();
						}	
						System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
						break;
					case "4": break label2;
					default: System.out.print("Please choose a valid option: ");		
					
					}					
					}while(true);
				
					break;
			case "4": System.out.println("======================");
					System.out.println("Good Bye "+employee.getEmployeeName());
					System.out.println("See you next time!");
					log.info("Admin logged out");
					System.exit(0);
			default: System.out.print("<< Please choose an option from 1-4 >>");
			}
		 }while(true);	
		
		}							
		
		//if the user is a coordinator then he can choose to perform training program maintenance or particpant enrollment
		else if(employee.getRole().equalsIgnoreCase("Coordinator")){
			log.info("Entered coodinator");;
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
			do{
			System.out.println();
			System.out.println("Choose the action you want to perform: ");
			System.out.println("--------------------------------------");
			System.out.println("|                                    |");
			System.out.println("|  1) Training Program Maintenance   |");
			System.out.println("|  2) Participant Enrolling          |");
			System.out.println("|  3) View Feedback Report           |");
			System.out.println("|  4) Log out                        |");
			System.out.println("|                                    |");
			System.out.println("--------------------------------------");
			
			choice  = scanner.next();		
			
			switch(choice){
			case "1":
				label3: do{
				log.info("Coodinator chose training program maintenance");
				System.out.println();
				System.out.println("****** Training Maintenance ******");
				System.out.println();
				System.out.println("Choose the action you want to perform");
				System.out.println("-------------------------------");
				System.out.println("|                             |");
				System.out.println("|  1) View training details   |");
				System.out.println("|  2) Add new training        |");
				System.out.println("|  3) Delete training         |");
				System.out.println("|  4) Exit                    |");
				System.out.println("|                             |");
				System.out.println("-------------------------------");	
				
				option = scanner.next();
				
				switch(option){
				case "1": 
					log.info("Coordinator chose to view training details");
					ArrayList<TrainingProgram> trainingProgramList = coordinator.viewTrainingList();
					
					System.out.format("%-15s %-15s %-25s %-15s %-20s %-20s","Training Code","Course Code","Course Name","Faculty Code","Start Date","End Date");
					System.out.println();
					System.out.println("--------------------------------------------------------------------------------------------------------------------");
					for(TrainingProgram trainingProgramObj: trainingProgramList){
						System.out.format("%-15s %-15s %-25s %-15s %-20s %-20s",trainingProgramObj.getTrainingCode(),trainingProgramObj.getCourseCode(),trainingProgramObj.getCourseName(),trainingProgramObj.getFacultyCode(),trainingProgramObj.getStartDate(),trainingProgramObj.getEndDate());
						System.out.println();
					}
					System.out.println("--------------------------------------------------------------------------------------------------------------------");
					break;
					
				case "2": 
					log.info("Coordinator chose to add new training");
					System.out.println();					
					System.out.println("Course List");										
					ArrayList<CourseMaster> courseList = coordinator.viewCourseList();				
					System.out.println("------------------------------------------------------------------------");
					System.out.format("%-15s %-25s %-10s","Course ID","Course Name","No of days");
					System.out.println();
					System.out.println("------------------------------------------------------------------------");
					
					for(CourseMaster courseObj: courseList){
						System.out.format("%-15s %-25s %-10s",courseObj.getCourseID(),courseObj.getCourseName(),courseObj.getNoOfDays());
						System.out.println();
					}	
					System.out.println("------------------------------------------------------------------------");
					
					System.out.print("Choose course to add to the training program: ");
					courseIDStr = reader.readLine();
					
					while(coordinator.checkCourseID(courseIDStr) == false){
						log.info("Wrong course ID was entered");
						System.out.println();
						System.out.print("Please enter valid course ID to add: ");
						courseIDStr = reader.readLine();
					}
					
					courseID = Integer.parseInt(courseIDStr);	
					course.setCourseID(courseID);
					
					System.out.println();
					System.out.println("Choose Faculty");					
					System.out.println("Faculty List");
					System.out.println("----------------------------------------");
					
					ArrayList<FacultySkill> facultySkillList = coordinator.viewFacultyList();
					
					System.out.format("%-15s %-35s","Faculty ID","Faculty SKill");
					System.out.println();
					System.out.println("----------------------------------------");
					for(FacultySkill facultySkillObj: facultySkillList){
						System.out.format("%-15s %-35s",facultySkillObj.getFacultyID(),facultySkillObj.getSkillSet());
						System.out.println();
					}
					System.out.println("----------------------------------------");
					facultyIDStr = reader.readLine();
				
					while(coordinator.checkFacultyID(facultyIDStr) == false){
						log.info("Wrong faculty ID was entered");
						System.out.println();
						System.out.print("Please enter valid faculty ID to add: ");	
						facultyIDStr = reader.readLine();
					}
					
					facultyID = Integer.parseInt(facultyIDStr);					
					DateValidator checkDate = new DateValidator();
					
					System.out.print("Enter the start date in (DD/MM/YYYY): ");
					startDateStr = scanner.next();
					while(checkDate.validate(startDateStr) == false){
						log.info("Wrong date was entered");
						System.out.println();
						System.out.print("Please enter a valid date: ");
						startDateStr = scanner.next();
					}
								
					System.out.print("Enter end date in (DD/MM/YYYY): ");
					endDateStr = scanner.next();
					while(checkDate.validate(endDateStr) == false){
						log.info("Wrong date was entered");
						System.out.println();
						System.out.print("Please enter a valid date: ");
						endDateStr = scanner.next();
					}
					training.setCourseCode(courseID);
					training.setFacultyCode(facultyID);
					training.setStartDateStr(startDateStr);
					training.setEndDateStr(endDateStr);
										
					int n = coordinator.addNewTraining(training);
					if(n>0){
						System.out.println("You have successfully added the training");
						log.info("New training was added");
					}
					else{
						System.out.println("Could not add the training");
						log.info("Training could not be added");
					   }			 								
					break;
					
				case "3": 
					log.info("Coordinator opted to delete training ");
					System.out.println();					
					System.out.println("Training List");
					System.out.println("----------------------");
					
					ArrayList<TrainingProgram> trainingList = coordinator.viewTrainings();
					
					for(TrainingProgram trainingProgramObj: trainingList){
						System.out.println(trainingProgramObj.getTrainingCode());
					}
					System.out.println();
					System.out.println("Enter the training ID you want to delete from the list:");
					
					trainingCodeStr = reader.readLine();
					
					while(coordinator.checkTrainingCode(trainingCodeStr) == false){
						log.info("Wrong training id was entered");
						System.out.println();
						System.out.print("Please enter valid training ID to delete: ");	
						trainingCodeStr =  reader.readLine();
					}
					trainingCode = Integer.parseInt(trainingCodeStr);
					training.setTrainingCode(trainingCode);
					
					int stat = coordinator.deleteTraining(training);
					
					if(stat>0){
						System.out.println("You have deleted the training "+trainingCode);
						log.info("Training was successfully deleted");
					}
					else{
						System.out.println("No trainings were deleted");
						log.info("Training could not be deleted");
					}				  
					break;
				case "4": break label3;
				default:System.out.print("Please choose options from 1-4 only: "); 	
				}
				}while(true);
					break; 
			case "2":
				log.info("Coordinator chose to enroll partipant to a training");
				System.out.println("*** PARTICIPANT ENROLL ***");
				System.out.println("=====================================================");
								
				System.out.println("Training Programs");
				System.out.println("--------------------------------------------------------");
				
				ArrayList<TrainingProgram> trainingProgramList = coordinator.viewTrainings();
				System.out.format("%-15s %-15s %-30s","Training Code","Course Code","Course Name");
				System.out.println();
				System.out.println("--------------------------------------------------------");
				
				for(TrainingProgram trainingProgramObj: trainingProgramList){
					System.out.format("%-15s %-15s %-30s",trainingProgramObj.getTrainingCode(),trainingProgramObj.getCourseCode(),trainingProgramObj.getCourseName());
					System.out.println();
				}				
				System.out.println();
				System.out.println("--------------------------------------------------------");
				
				System.out.print("Enter the training program code to enroll the participant to: ");
				
				trainingCodeStr =  reader.readLine();
				
				while(coordinator.checkTrainingCode(trainingCodeStr) == false){
					log.info("Wrong training Code was entered");
					System.out.println();
					System.out.print("Please enter valid training ID to enroll: ");
					trainingCodeStr =  reader.readLine();
				}
				
				trainingCode = Integer.parseInt(trainingCodeStr);				
				System.out.println("---------------------------------------------------");
				System.out.println("Participant list");
				System.out.println("---------------------------------------------------");
				
				ArrayList<Employee> participantList = coordinator.viewParticipantList();
				for(Employee emp: participantList){
					System.out.println(emp.getEmployeeID());
				}
				System.out.println();
				System.out.print("Choose the participant ID to enroll: ");
				employeeIDStr =  reader.readLine();
				
				while(coordinator.checkParticipantID(employeeIDStr) == false){
					log.info("Wrong participant id was entered");
					System.out.println();
					System.out.print("Please enter valid participant ID to enroll: ");	
					employeeIDStr =  reader.readLine();
				}
				
				employeeID = Integer.parseInt(employeeIDStr);
							
					int stat = coordinator.participantEnroll(trainingCode, employeeID);				
					if(stat>0){
					System.out.println("You have successfully enrolled participant "+employeeID+" to the training "+trainingCode);
					log.info("Participant was successfully enrolled to a training");
					}
					else{
						System.out.println("No participant was enrolled into a training");
						log.info("Participant could not be enrolled to training");
					}				  			
					break;
			case "3":
				System.out.println("*** FEEDBACK REPORT ***");
				System.out.println();
				
				label2: do{	
				
				System.out.println("-------------------------------------------");
				System.out.println("|                                          |");
				System.out.println("|   1) Training Feedback Report for month  |");
				System.out.println("|   2) Faculty Feedback Report for month   |");
				System.out.println("|   3) General Feedback Report             |");
				System.out.println("|   4) Exit                                |");
				System.out.println("|                                          |");
				System.out.println("-------------------------------------------");
				
				String opt = scanner.next();				
								
					switch(opt){
					case "1": 
						log.info("Coordinator chose to view monthly feedback");
						System.out.println();
						System.out.println("=========================================");
						System.out.println("MONTHLY TRAINING PROGRAM FEEDBACK");
						System.out.println("=========================================");
						
						System.out.println("Months for which feedback is available");
						System.out.println("---------------------------------------");
						ArrayList<Feedback> monthList = feedback.getMonthsFromFeedbackList();
						for(Feedback months: monthList){
							System.out.println(months.getMonth());
						}
												
						System.out.println();
						System.out.print("Enter the month (1-12) you want to view feedback for: ");							
						monthStr =  reader.readLine();
						
						while(feedback.checkMonth(monthStr) == false){
							System.out.println();
							System.out.print("Please enter valid month to view feedback: ");
							monthStr =  reader.readLine();
						}					
						
						month = Integer.parseInt(monthStr);
						ArrayList<Feedback> feedbackList = feedback.viewTrainingProgramReport(month);
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%-20s %-15s %-25s %-10s %-10s %-10s %-10s %-10s","Date","Training","Faculty","Pres&COmm","ClrfyDbt","Time Mgmt","Handout","HwSwNw");
						System.out.println();
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: feedbackList){
							System.out.format("%-20s %-15s %-25s %-10s %-10s %-10s %-10s %-10s",feedbackObj.getEntryDate(),feedbackObj.getTrainingCode(),feedbackObj.getEmployeeName(),feedbackObj.getFbPrsComm(),feedbackObj.getFbClrfyDbts(),feedbackObj.getFbTm(),feedbackObj.getFbHandout(),feedbackObj.getFbHwSwNtwk());
							System.out.println();
						}
						System.out.println();
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						
						float average = feedback.findMonthlyAverage(month);
						System.out.println();
						System.out.println("Average Score: "+ average);											
						break;
						
					case "2":
						System.out.println();
						System.out.println("===========================");
						System.out.println("MONTHLY FACULTY FEEDBACK");
						System.out.println("===========================");						
						System.out.println("Months for which feedback is available");
						System.out.println("---------------------------------------");
						ArrayList<Feedback> monthsList = feedback.getMonthsFromFeedbackList();
						for(Feedback months: monthsList){
							System.out.println(months.getMonth());
						}												
						System.out.println();
						System.out.print("Enter the month (1-12) you want to view feedback for: ");							
						monthStr =  reader.readLine();
						
						while(feedback.checkMonth(monthStr) == false){
							System.out.println();
							System.out.print("Please enter valid month to view feedback: ");
							monthStr =  reader.readLine();
						}					
						month = Integer.parseInt(monthStr);
						
						System.out.println();
						System.out.println("Choose faculty to view feedback for");
						System.out.println("---------------------");
						
						ArrayList<Feedback> facultyList = feedback.getFacultyList();
						for(Feedback faculty: facultyList){
							System.out.println(faculty.getFacultyID());
						}
						facultyIDStr =  reader.readLine();
						
						while(feedback.checkFacultyID(facultyIDStr) == false){
							System.out.println();
							System.out.println("Please enter valid faculty ID");
							facultyIDStr =  reader.readLine();
						}
						facultyID = Integer.parseInt(facultyIDStr);
						
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%-15s %-15s %-10s %-10s %-10s %-10s %-10s","Date","Training","Pres&COmm","ClrfyDbt","Time Mgmt","Handout","HwSwNw");
						System.out.println();
						ArrayList<Feedback> facultyFeedbackList = feedback.viewFacultyProgramReport(month,facultyID);
						
						for(Feedback feedbackObj: facultyFeedbackList){
							System.out.format("%-15s %-15s %-10s %-10s %-10s %-10s %-10s",feedbackObj.getEntryDate(),feedbackObj.getTrainingCode(),feedbackObj.getFbPrsComm(),feedbackObj.getFbClrfyDbts(),feedbackObj.getFbTm(),feedbackObj.getFbHandout(),feedbackObj.getFbHwSwNtwk());
							System.out.println();
						}
						
						float avg = feedback.findFacultyMonthlyAverage(month, facultyID);
						System.out.println();
						System.out.println("Average Score: "+ avg);
						break;
						
					case "3": 
						log.info("Coordinator chose to view general feedback");
						System.out.println();
						System.out.println("=====================");
						System.out.println("GENERAL FEEDBACK");
						System.out.println("=====================");
						
						ArrayList<Feedback> generalFeedbackList = feedback.viewGeneralFeedback();
						
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.format("%-20s %-15s %-20s %-20s %-10s %-10s %-10s %-10s %-10s","Date","Training","Participant ID","Faculty","Pres&COmm","ClrfyDbt","Time Mgmt","Handout","HwSwNw");
						System.out.println();
						System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj:  generalFeedbackList){
							System.out.format("%-20s %-15s %-20s %-20s %-10s %-10s %-10s %-10s %-10s",feedbackObj.getEntryDate(),feedbackObj.getTrainingCode(),feedbackObj.getParticipantID(),feedbackObj.getEmployeeName(),feedbackObj.getFbPrsComm(),feedbackObj.getFbClrfyDbts(),feedbackObj.getFbTm(),feedbackObj.getFbHandout(),feedbackObj.getFbHwSwNtwk());
							System.out.println();
						}	
						System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------");
						break;
					case "4": break label2;
					default: System.out.println("<< Please choose a valid option >>");						
					}
					
					}while(true);				
					break;
			case "4":
					System.out.println("====================");
					System.out.println("Good Bye "+employee.getEmployeeName());
					System.out.println("See you next time!");
					System.exit(0);
			default: System.out.println("<< Please choose an option from 1-4 >>");
			}
			}while(true);
		}
		else if(employee.getRole().equalsIgnoreCase("Participant")){
			log.info("Entered as participant");
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
			System.out.println("Please rate the training from 1-5 where");
			System.out.println("5 - Excellent:The ideal way of doing it");
			System.out.println("4 - Good:No pain areas or concern but could have been better");
			System.out.println("3 - Average: There are concerns but not significant");
			System.out.println("2 - Below Average: Needs improvement and is salvageable");
			System.out.println("1 - Poor: This way of doing things must change");
						
			System.out.println();
			System.out.println("============ Enter Feedback for the training attended ============");
						
			System.out.print("1) Presentation and communication skills of faculty: ");
			fbPrsCommStr =  reader.readLine();
			while(participant.checkFeedbackValue(fbPrsCommStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.println();
				System.out.print("Please enter a number between 1-5: ");
				fbPrsCommStr =  reader.readLine();			
			}			
			System.out.print("2) Ability to clarify doubts and explain difficult points: ");
			fbClrfyDbtsStr =  reader.readLine();
			while(participant.checkFeedbackValue(fbClrfyDbtsStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5: ");				
				fbClrfyDbtsStr =  reader.readLine();				
			}
			System.out.print("3) Time management in completing the contents: ");
			fbTmStr =  reader.readLine();
			while(participant.checkFeedbackValue(fbTmStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5: ");
				fbTmStr =  reader.readLine();				
			}
			System.out.print("4) Handout provided(Student Guide): ");
			fbHandoutStr =  reader.readLine();
			while(participant.checkFeedbackValue(fbHandoutStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5");
				fbHandoutStr =  reader.readLine();				
			}
			System.out.print("5) Hardware, software and network availability: ");
			fbHwSwNtwkStr =  reader.readLine();
			while(participant.checkFeedbackValue(fbHwSwNtwkStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5");
				fbHwSwNtwkStr =  reader.readLine();
			}
			System.out.print("Comments:");
			comments = reader.readLine();
			
			while(participant.checkIfValidMessage(comments) == false){
				log.info("Comments provided was of inadequate length");
				System.out.println();
				System.out.print("Provide minimum input of 10 and maximum of 150 characters: ");
				comments = reader.readLine();
			}
			System.out.print("Suggestions:");
			suggestions = reader.readLine();
			while(participant.checkIfValidMessage(suggestions) == false){
				log.info("Suggestions provided was of inadequate length");
				System.out.println();
				System.out.print("Provide minimum input of 10 and maximum of 150 characters: ");
				suggestions = reader.readLine();
			}			
			
			fbPrsComm = Integer.parseInt(fbPrsCommStr);
			fbClrfyDbts = Integer.parseInt(fbClrfyDbtsStr);
			fbTm = Integer.parseInt(fbTmStr);
			fbHandout = Integer.parseInt(fbHandoutStr);
			fbHwSwNtwk = Integer.parseInt(fbHwSwNtwkStr);
		
			// The feedback entered by the user is then set in the bean class
			feed.setFbPrsComm(fbPrsComm);
			feed.setFbClrfyDbts(fbClrfyDbts);
			feed.setFbTm(fbTm);
			feed.setFbHandout(fbHandout);
			feed.setFbHwSwNtwk(fbHwSwNtwk);
			feed.setComments(comments);
			feed.setSuggestions(suggestions);
						
			status = participant.provideFeedback(employee, feed);
			//if status is greater than 0 it means rows were updated and hence a display message can be displayed
			if(status>0){
				log.info("Feedback was successfully entered");
				System.out.println("Thank you for the feedback!");
				System.exit(0);
			 }
			else{
				log.info("Could not update feedback");
				System.out.println("Sorry! Could not update your feedback.");
			}			
		   }
		}		
		else{
			log.info("Wrong credentials were entered");
			System.out.println();
			System.out.println("<< You have entered the wrong credentials >>");
			attempt++;	
		 }
			
		}catch(FMSException e){
			System.err.println(e);
		} catch (SQLException e) {
			System.err.println(e);
		} catch (IOException e) {
			System.err.println("Could not read the input");
		}
				
		}while(true);
	}

}
