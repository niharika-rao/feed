package com.cg.fms.ui;

import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.Feedback;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.AdminServiceImpl;
import com.cg.fms.service.CoordinatorServiceImpl;
import com.cg.fms.service.EmployeeServiceImpl;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.IAdminService;
import com.cg.fms.service.ICoordinatorService;
import com.cg.fms.service.IEmployeeService;
import com.cg.fms.service.IFeedbackService;
import com.cg.fms.service.IParticipantService;
import com.cg.fms.service.ParticipantServiceImpl;

/* In this class, the user enters his user id and password and the menu will be displayed based 
 * on the role of the user which can be admin, coordinator or a participant. The admin has the privileges
 * to maintain faculty skill and course. The coordinator has the privileges to maintain the training program
 * and participant enrollment. The participant can login and enter the feedback for the training attended*/
public class EmployeeUI {

	static int employeeID;
	static String password;
	static String role;	
	
	public static void main(String[] args) {
		int status = 0, action=0;
		int attempt=0;
		int month;
		boolean check;
		
		String choice = null, option = null;
				
		String courseName;
		int noOfDays = 0;
		
		int courseID;
		int facultyID;
		int trainingCode;
		int employeeID;
	
		int participantID;
		int fbPrsComm;
		int fbClrfyDbts;
		int fbTm;
		int fbHandout;
		int fbHwSwNtwk;
		String comments;
		String suggestions;
		
		String startDate;
		
		
		CourseMaster course = new CourseMaster();
		TrainingProgram training = new TrainingProgram();
		Feedback feed = new Feedback();
		
		Scanner in = new Scanner(System.in);
		
		IEmployeeService service = new EmployeeServiceImpl();
		IAdminService admin = new AdminServiceImpl();
		ICoordinatorService coordinator = new CoordinatorServiceImpl();
		IParticipantService participant = new ParticipantServiceImpl();
		IFeedbackService feedback = new FeedbackServiceImpl();
		EmployeeServiceImpl empSer = new EmployeeServiceImpl();
		Employee employee = new Employee();
				
		//The user enters their employee id and password
		System.out.println("*** Feedback Management System ***");
		
		
			System.out.println();
			System.out.println("=================LOGIN===================");
			System.out.println();
			System.out.println("Enter the Employee ID:");
			employeeID = in.nextInt();				
			System.out.println("Enter the Password:");
			password = in.next();
				
		/*The entered credentials are set in the bean class and the object is sent 
		 * to the service layer which then calls the dao layer where the user is authenticated
		 */
		employee.setEmployeeID(employeeID);
		
		employee.setPassword(password);
		
		
		try{
		check = service.login(employee);	
		//if true is returned it means the entered userId and password is correct and the menu will be displayed accordingly
		//log.info("Login successful");
		
		if(check){
		//If the role is admin, then he can choose if he wants to perform faculty skill maintenance or course maintenance
			if(employee.getRole().equalsIgnoreCase("Admin")){
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
			
			
			do{
			System.out.println();
			System.out.println("--------------------------------------------");
			System.out.println(" Choose the action you want to perform: ");
			System.out.println("--------------------------------------------");
			System.out.println("1) Faculty Skill Maintenance");
			System.out.println("2) Course Maintenance");
			System.out.println("3) View Feedback Report");
			System.out.println("4) Log out");
						
			
				choice  = in.next();			
			
			//the admin is displayed a menu to choose from based on the requirement
			switch(choice){
			case "1" : 
				//this displays the faculty and their skills mapped to the courses they teach
				//An array list of the table is obtained and displayed here
				ArrayList<FacultyMaintenance> facultyList = admin.facultyMaintenance();			
				System.out.println("****** FACULTY SKILL MAINTENANCE ******");
				System.out.println();
				System.out.println("FACULTY CODE"+"\t\t"+"SKILL SET"+"\t\t\t"+"COURSE CODE"+"\t\t"+"COURSE NAME"+"\t\t"+"NO OF DAYS");
				System.out.println("-----------------------------------------------------------------------------------------------------------------------");
				for (FacultyMaintenance faculty : facultyList) 
				{
					System.out.println(faculty.getFacultyCode()+"\t\t"+faculty.getSkillSet()+"\t\t"+faculty.getCourseCode()+"\t\t\t"+faculty.getCourseName()+"\t\t\t"+faculty.getNoOfDays());
				}
				break;
				
			case "2":
				label1: do{
				//here the admin can choose between viewing, adding and deleting courses
				System.out.println();
				System.out.println("******COURSE MAINTENANCE******");
				System.out.println();
				System.out.println("Choose the action you want to perform");
				System.out.println("1)View Course details");
				System.out.println("2)Add new course");
				System.out.println("3)Delete course");
				System.out.println("4) Exit");
				
				option = in.next();
				
				switch(option){
				case "1": 
					ArrayList<CourseMaster> courseList = admin.viewCourse();
					//here the course name along with the course id is displayed
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Course ID"+"\t\t"+"Course Name"+"\t\t\t"+"No of days"+"\t\t");
					System.out.println("------------------------------------------------------------------------");
					
					for(CourseMaster courseObj: courseList){
						System.out.println(courseObj.getCourseID()+"\t\t\t"+courseObj.getCourseName()+"\t\t\t\t"+courseObj.getNoOfDays());
					}
					break;
				case "2":
					System.out.println();
					System.out.println("Enter the Course Name");
					courseName = in.next();
					System.out.println("Enter the Course duration");
					noOfDays = in.nextInt();
					/*To add a new course, the course name and the duration is taken from the admin and set in
					the bean class and the object is passed along to the addNewCourse method*/
					course.setCourseName(courseName);
					course.setNoOfDays(noOfDays);
					
					int n = admin.addNewCourse(course);
					//if the number of rows returned is more than 1, then a success message is displayed
					if(n>0){
						System.out.println();
						System.out.println("You have added a new course");
						break;
					}
					else{
						System.out.println("No new courses were added");
					}				
				
					break;
					
				case "3": 
					//the course list is displayed first and the admin has to choose which course he wants to delete
					System.out.println();
					System.out.println("Enter the course ID you want to delete");
					System.out.println("----------------------------------------");
					System.out.println("Course List");				
					
					ArrayList<CourseMaster> listOfCourses = admin.viewCourse();
					
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Course ID"+"\t\t"+"Course Name"+"\t\t\t"+"No of days"+"\t\t");
					System.out.println("------------------------------------------------------------------------");
					
					for(CourseMaster courseObj: listOfCourses){
						System.out.println(courseObj.getCourseID()+"\t\t"+courseObj.getCourseName()+"\t\t"+courseObj.getNoOfDays());
					}				
					courseID = in.nextInt();
					
					//the entered course id is then sent to delete from the database
					int stat = admin.deleteCourse(courseID);
					if(stat>0){
						System.out.println("You have deleted the course "+courseID);
					}else{
						System.out.println("No courses were deleted");
					}
					break;
				case "4": break label1;
				default: System.out.println("Please choose options from 1-4 only");
			   }
			}while(true);
						break;
				
			case "3" :
				System.out.println("*** FEEDBACK REPORT ***");
				System.out.println();
				
				label2: do{	
					
				System.out.println();
				System.out.println("1) Training Feedback Report for month");
				System.out.println("2) Faculty Feedback Report for month");
				System.out.println("3) General Feedback Report");
				System.out.println("4) Exit");
				
				String opt = in.next();				
								
					switch(opt){
					case "1": System.out.println();
							System.out.println("*** MONTHLY TRAINING PROGRAM FEEDBACK ***");
							System.out.println("-----------------------------------------");
							
							System.out.println("Enter the month you want to view feedback for");
							month = in.nextInt();
							ArrayList<Feedback> feedbackList = feedback.viewTrainingProgramReport(month);
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
							System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
							
							for(Feedback feedbackObj: feedbackList){
								System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
							}
							
							
							float average = feedback.findMonthlyAverage(month);
							System.out.println();
							System.out.println("Average Score: "+ average);
							
							break;
					case "2": 
						System.out.println();
						System.out.println("*** MONTHLY FACULTY FEEDBACK ***");
						System.out.println("-----------------------------------------");
						
						System.out.println("Enter the month you want to view feedback for");
						month = in.nextInt();
						
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						ArrayList<Feedback> facultyFeedbackList = feedback.viewFacultyProgramReport(month);
						
						for(Feedback feedbackObj: facultyFeedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}
						
						break;
					case "3": 
						System.out.println();
						System.out.println("*** GENERAL FEEDBACK ***");
						System.out.println("-----------------------------------------");
						
						ArrayList<Feedback> generalFeedbackList = feedback.viewGeneralFeedback();
						System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Participant name"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: generalFeedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getParticipantID()+"\t\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}
						
						break;
					case "4": break label2;
					default: System.out.println("Please choose a valid option");		
					
					}
					
					}while(true);
				
					break;
			case "4": System.out.println("===================");
					System.out.println("Good Bye "+employee.getEmployeeName());
					System.out.println("See you next time!");
					System.exit(0);
			default: System.out.println("Please choose an option from 1-4");
			}
		 }while(true);	
		
		}							
		
		//if the user is a coordinator then he can choose to perform training program maintenance or particpant enrollment
		else if(employee.getRole().equalsIgnoreCase("Coordinator")){
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
			System.out.println("--------------------------------------------");
			do{
			System.out.println("--------------------------------------------");
			System.out.println("Choose the action you want to perform: ");
			System.out.println("--------------------------------------------");
			System.out.println("1) Training Program Maintenance");
			System.out.println("2) Participant Enrolling");
			System.out.println("3) View Feedback Report");
			System.out.println("4) Log out");
			
			choice  = in.next();
			
			
			switch(choice){
			case "1":
				label3: do{
				System.out.println();
				System.out.println("****** Training Maintenance ******");
				System.out.println();
				System.out.println("Choose the action you want to perform");
				System.out.println("1) View training details");
				System.out.println("2) Add new training");
				System.out.println("3) Delete training");
				System.out.println("4) Exit");
				
				
				option = in.next();
				
				switch(option){
				case "1": 
					ArrayList<TrainingProgram> trainingProgramList = coordinator.viewTrainingList();
					
					System.out.println("Training Code"+"\t"+"Course Code"+"\t"+"Course Name"+"\t"+"Faculty Code"+"\t"+"Start Date"+"\t"+"End Date");
					System.out.println("-----------------------------------------------------------------------------------");
					for(TrainingProgram trainingProgramObj: trainingProgramList){
						System.out.println(trainingProgramObj.getTrainingCode()+"\t\t"+trainingProgramObj.getCourseCode()+"\t\t"+trainingProgramObj.getCourseName()+"\t\t"+trainingProgramObj.getFacultyCode()+"\t\t"+trainingProgramObj.getStartDate()+"\t\t"+trainingProgramObj.getEndDate());
						
					}
					break;
					
				case "2": 
					System.out.println();
					System.out.println("Choose course to add to the training program");
					System.out.println("Course List");
										
					ArrayList<CourseMaster> courseList = coordinator.viewCourseList();
					
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Course ID"+"\t\t"+"Course Name"+"\t\t\t"+"No of days"+"\t\t");
					System.out.println("------------------------------------------------------------------------");
					
					for(CourseMaster courseObj: courseList){
						System.out.println(courseObj.getCourseID()+"\t\t"+courseObj.getCourseName()+"\t\t"+courseObj.getNoOfDays());
					}
					
					courseID = in.nextInt();
					course.setCourseID(courseID);
					
					System.out.println("Choose Faculty");					
					System.out.println("Faculty List");
					System.out.println("----------------------------------------");
					
					ArrayList<FacultySkill> facultySkillList = coordinator.viewFacultyList();
					
					System.out.println("Faculty ID"+"\t\t"+"Faculty SKill");
					for(FacultySkill facultySkillObj: facultySkillList){
						System.out.println(facultySkillObj.getFacultyID()+"\t\t"+facultySkillObj.getSkillSet());
					}
					
					facultyID = in.nextInt();
					
					/*System.out.println("Enter the start date");
					startDate = in.next();
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/mm/yyyy");
					LocalDate startDateFormatted  = LocalDate.parse(startDate, formatter);
					
					System.out.println("Enter the end date");
					String endDate = in.next();
					LocalDate endDateFormatted  = LocalDate.parse(endDate, formatter);
					
					training.setCourseCode(courseID);
					training.setFacultyCode(facultyID);
					training.setStartDate(startDateFormatted);
					training.setEndDate(endDateFormatted);
					System.out.println("in main");
					System.out.println(courseID + facultyID);
					System.out.println(startDateFormatted);
					System.out.println(endDateFormatted);*/
					
					int n = coordinator.addNewTraining(courseID, facultyID);
					break;
					
				case "3": 
					System.out.println();
					System.out.println("Enter the training you want to delete from the list:");
					System.out.println();
					System.out.println("Training List");
					System.out.println("----------------------------------------");
					
					ArrayList<TrainingProgram> trainingList = coordinator.viewTrainings();
					
					for(TrainingProgram trainingProgramObj: trainingList){
						System.out.println(trainingProgramObj.getTrainingCode());
					}
					
					trainingCode = in.nextInt();
					training.setTrainingCode(trainingCode);
					
					int stat = coordinator.deleteTraining(training);
					
					if(stat>0){
						System.out.println("You have deleted the training "+trainingCode);
					}
					else{
						System.out.println("No trainings were deleted");
					}
					break;
				case "4": break label3;
					
				}
				}while(true);
					break; 
			case "2": 
				System.out.println("*** PARTICIPANT ENROLL ***");
				System.out.println("=====================================================");
								
				System.out.println("Training Programs");
				System.out.println("---------------------------------------------------");
				
				ArrayList<TrainingProgram> trainingProgramList = coordinator.viewTrainings();
				System.out.println("Training Code"+"\t\t"+"Course Code"+"\t\t"+"Course Name");
				
				for(TrainingProgram trainingProgramObj: trainingProgramList){
					System.out.println(trainingProgramObj.getTrainingCode()+"\t\t"+trainingProgramObj.getCourseCode()+"\t\t"+trainingProgramObj.getCourseName());
				}
				System.out.println("Enter the training program code to enroll the participant to");
				trainingCode = in.nextInt();
				
				System.out.println("---------------------------------------------------");
				System.out.println("Participant list");
				System.out.println("---------------------------------------------------");
				
				ArrayList<Employee> participantList = coordinator.viewParticipantList();
				for(Employee emp: participantList){
					System.out.println(emp.getEmployeeID());
				}
				
				System.out.println("Choose the participant to enroll");
				employeeID = in.nextInt();
				int stat = coordinator.participantEnroll(trainingCode, employeeID);
				
				if(stat>0){
					System.out.println("You have successfully enrolled participant "+employeeID+" to the training "+trainingCode);
				}
				else{
					System.out.println("No participant was enrolled into a training");
				}
					break;
			case "3":
				System.out.println("*** FEEDBACK REPORT ***");
				System.out.println();
				
				label2: do{	
					
				System.out.println();
				System.out.println("1) Training Feedback Report for month");
				System.out.println("2) Faculty Feedback Report for month");
				System.out.println("3) General Feedback Report");
				System.out.println("4) Exit");
				
				String opt = in.next();				
								
					switch(opt){
					case "1": System.out.println();
							System.out.println("*** MONTHLY TRAINING PROGRAM FEEDBACK ***");
							System.out.println("-----------------------------------------");
							
							System.out.println("Enter the month you want to view feedback for");
							month = in.nextInt();
							ArrayList<Feedback> feedbackList = feedback.viewTrainingProgramReport(month);
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
							System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
							System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
							
							for(Feedback feedbackObj: feedbackList){
								System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
							}
							
							
							float average = feedback.findMonthlyAverage(month);
							System.out.println();
							System.out.println("Average Score: "+ average);
							
							break;
					case "2": break;
					case "3": 
						System.out.println();
						System.out.println("*** GENERAL FEEDBACK ***");
						System.out.println("-----------------------------------------");
						
						ArrayList<Feedback> generalFeedbackList = feedback.viewGeneralFeedback();
						System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Participant name"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: generalFeedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getParticipantID()+"\t\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}
						
						break;
					case "4": break label2;
					default: System.out.println("Please choose a valid option");		
					
					}
					
					}while(true);			
				
					break;
			case "4": System.out.println("================");
					System.out.println("Good Bye "+employee.getEmployeeName());
					System.out.println("See you next time!");
					System.exit(0);
			default: System.out.println("Please choose an option from 1-4");
			}
			}while(true);
		}
		else if(employee.getRole().equalsIgnoreCase("Participant")){
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
			System.out.println("Please rate the training from 1-5 where");
			System.out.println("5 - Excellent:The ideal way of doing it");
			System.out.println("4 - Good:No pain areas or concern but could have been better");
			System.out.println("3 - Average: There are concerns but not significant");
			System.out.println("2 - Below Average: Needs improvement and is salvageable");
			System.out.println("1 - Poor: This way of doing things must change");
			
			System.out.println();
			System.out.println("============ Enter Feedback for the training attended ============");
						
			System.out.println("1) Presentation and communication skills of faculty	");
			fbPrsComm = in.nextInt();
			System.out.println("2) Ability to clarify doubts and explain difficult points	");
			fbClrfyDbts = in.nextInt();
			System.out.println("3) Time management in completing the contents 	");
			fbTm = in.nextInt();
			System.out.println("4) Handout provided(Student Guide)	");
			fbHandout = in.nextInt();
			System.out.println("5) Hardware, software and network availability	");
			fbHwSwNtwk = in.nextInt();
			System.out.println("Comments");
			String dummy = in.nextLine();
			comments = in.nextLine();
			System.out.println("Suggestions");
			suggestions = in.nextLine();
			
			
			// The feedback entered by the user is then set in the bean class
			feed.setFbPrsComm(fbPrsComm);
			feed.setFbClrfyDbts(fbClrfyDbts);
			feed.setFbTm(fbTm);
			feed.setFbHandout(fbHandout);
			feed.setFbHwSwNtwk(fbHwSwNtwk);
			feed.setComments(comments);
			feed.setSuggestions(suggestions);
									
			
			status = participant.provideFeedback(employee, feed);
			//if status is greater than 0 it means rows were updated and hence a display message can be displayed
			if(status>0){
				System.out.println("Thank you for the feedback!");
				System.exit(0);
			 }
			
		   }
		}		
		else{
			System.out.println("Wrong credentials");
			//attempt++;
		 }
		
		}catch(FMSException e){
			System.err.println(e);
		} catch (SQLException e) {
			System.err.println(e);
		}
	
	}

}
