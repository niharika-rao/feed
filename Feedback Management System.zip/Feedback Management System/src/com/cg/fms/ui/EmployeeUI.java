package com.cg.fms.ui;

import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;





import org.apache.log4j.Logger;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.Employee;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.Feedback;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.exception.FMSException;
import com.cg.fms.service.AdminServiceImpl;
import com.cg.fms.service.CoordinatorServiceImpl;
import com.cg.fms.service.DateValidator;
import com.cg.fms.service.EmployeeServiceImpl;
import com.cg.fms.service.FeedbackServiceImpl;
import com.cg.fms.service.IAdminService;
import com.cg.fms.service.ICoordinatorService;
import com.cg.fms.service.IEmployeeService;
import com.cg.fms.service.IFeedbackService;
import com.cg.fms.service.IParticipantService;
import com.cg.fms.service.ParticipantServiceImpl;

/* In this class, the user enters his user id and password and the menu will be displayed based 
 * on the role of the user which can be admin, coordinator or a participant. The admin has the privileges
 * to maintain faculty skill and course. The coordinator has the privileges to maintain the training program
 * and participant enrollment. The participant can login and enter the feedback for the training attended*/
public class EmployeeUI {

	static String employeeIDStr;
	static int employeeID;
	static String password;
	static String role;
	
	
	public static void main(String[] args) {
		Logger log = Logger.getRootLogger();
		
		int status = 0, action=0;
		int attempt=0;
		int count = 0;
		int month;
		boolean check;
		
		String choice = null, option = null;
				
		String courseName;
		int noOfDays = 0;
		
		int courseID;
		int facultyID;
		int trainingCode;
		int employeeID = 0;
	
		int participantID;
		int fbPrsComm;
		int fbClrfyDbts;
		int fbTm;
		int fbHandout;
		int fbHwSwNtwk;
		String comments;
		String suggestions;
		
		String participantIDStr;
		String fbPrsCommStr;
		String fbClrfyDbtsStr;
		String fbTmStr;
		String fbHandoutStr;
		String fbHwSwNtwkStr;
		
		String startDateStr;
		String endDateStr;
		String noOfDaysStr;
		String courseIDStr;
		String trainingCodeStr;
		String monthStr;
		String facultyIDStr;	
		
		CourseMaster course = new CourseMaster();
		TrainingProgram training = new TrainingProgram();
		Feedback feed = new Feedback();
		
		Scanner in = new Scanner(System.in);
		
		IEmployeeService service = new EmployeeServiceImpl();
		IAdminService admin = new AdminServiceImpl();
		ICoordinatorService coordinator = new CoordinatorServiceImpl();
		IParticipantService participant = new ParticipantServiceImpl();
		IFeedbackService feedback = new FeedbackServiceImpl();
		Employee employee = new Employee();
				
		//The user enters their employee id and password
		System.out.println("*** Feedback Management System ***");
		do{		
			if(attempt>=3){
				System.err.println("Too many invalid attempts. Please try later!");
				log.info("Tried to login with wrong credentials for more than 3 times");
				break;
			}
			System.out.println();
			System.out.println("=================LOGIN===================");
			System.out.println();
			System.out.print("Enter the Employee ID:");
			employeeIDStr = in.next();			
				
				if(!service.validateUserID(employeeIDStr))	
				{
					System.out.println();
					System.err.println("Please enter valid EmployeeID: ");
					attempt++;
					continue;
				}	
				employeeID = Integer.parseInt(employeeIDStr);
				System.out.print("Enter the Password: ");
				password = in.next();

		/*The entered credentials are set in the bean class and the object is sent 
		 * to the service layer which then calls the dao layer where the user is authenticated
		 */
		employee.setEmployeeID(employeeID);		
		employee.setPassword(password);
				
		try{		
		check = service.login(employee);	
		//if true is returned it means the entered userId and password is correct and the menu will be displayed accordingly
		//log.info("Login successful");
		
		if(check){
		//If the role is admin, then he can choose if he wants to perform faculty skill maintenance or course maintenance
			if(employee.getRole().equalsIgnoreCase("Admin")){
			log.info("Entered admin page");
			System.out.println();
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
						
			do{
			System.out.println();
			System.out.println(" Choose the action you want to perform: ");
			System.out.println("-----------------------------------------");
			System.out.println("|                                       |");
			System.out.println("|      1) Faculty Skill Maintenance     |");
			System.out.println("|      2) Course Maintenance            |");
			System.out.println("|      3) View Feedback Report          |");
			System.out.println("|      4) Log out                       |");
			System.out.println("|                                       |");
			System.out.println("-----------------------------------------");			
			choice  = in.next();				
			
			//the admin is displayed a menu to choose from based on the requirement
			switch(choice){
			case "1" : 
				//this displays the faculty and their skills mapped to the courses they teach
				//An array list of the table is obtained and displayed here
				ArrayList<FacultyMaintenance> facultyList = admin.facultyMaintenance();	
				System.out.println("===============================");
				System.out.println("FACULTY SKILL LIST");
				System.out.println("===============================");
				System.out.println();
				System.out.println("FACULTY CODE"+"\t\t"+"SKILL SET"+"\t\t\t"+"COURSE CODE"+"\t\t"+"COURSE NAME"+"\t\t"+"NO OF DAYS");
				System.out.println("-----------------------------------------------------------------------------------------------------------------------");
				for (FacultyMaintenance faculty : facultyList) 
				{
					System.out.println(faculty.getFacultyCode()+"\t\t"+faculty.getSkillSet()+"\t\t"+faculty.getCourseCode()+"\t\t"+faculty.getCourseName()+"\t\t\t"+faculty.getNoOfDays());
				}
				System.out.println("-----------------------------------------------------------------------------------------------------------------------");
				break;
				
			case "2":
				label1: do{
				//here the admin can choose between viewing, adding and deleting courses
				System.out.println();
				System.out.println("===============================");
				System.out.println("COURSE MAINTENANCE");
				System.out.println("===============================");
				System.out.println("Choose the action you want to perform");
				System.out.println("------------------------------");
				System.out.println("|                            |");
				System.out.println("|    1)View Course details   |");
				System.out.println("|    2)Add new course        |");
				System.out.println("|    3)Delete course         |");
				System.out.println("|    4)Exit                  |");
				System.out.println("|                            |");
				System.out.println("------------------------------");
				option = in.next();
				
				switch(option){
				case "1": 
					ArrayList<CourseMaster> courseList = admin.viewCourse();
					//here the course name along with the course id is displayed
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Course ID"+"\t\t"+"Course Name"+"\t\t\t"+"No of days"+"\t\t");
					System.out.println("------------------------------------------------------------------------");
					
					for(CourseMaster courseObj: courseList){
						System.out.println(courseObj.getCourseID()+"\t\t\t"+courseObj.getCourseName()+"\t\t\t\t"+courseObj.getNoOfDays());
					}
					break;
				case "2":
					count = 0;
					System.out.println();
					System.out.print("Enter the Course Name: ");
					courseName = in.next();
					System.out.println("Enter the Course duration in terms of number of days: ");
					noOfDaysStr = in.next();
					
					while(admin.checkIfInt(noOfDaysStr) == false){
						System.out.println("<< Please enter valid course duration >>");
						System.out.println();
						noOfDaysStr = in.next();
					}
					
					/*To add a new course, the course name and the duration is taken from the admin and set in
					the bean class and the object is passed along to the addNewCourse method*/
					
					noOfDays = Integer.parseInt(noOfDaysStr);	
					course.setCourseName(courseName);
					course.setNoOfDays(noOfDays);
					
					int n = admin.addNewCourse(course);
					//if the number of rows returned is more than 1, then a success message is displayed
					if(n>0){
						System.out.println();
						System.out.println("You have added a new course!");
						break;
					}
					else{
						System.out.println("No new courses were added");
					}			  
					break;
					
				case "3": 
					//the course list is displayed first and the admin has to choose which course he wants to delete
					System.out.println();					
					System.out.println("Course List");				
					
					ArrayList<CourseMaster> listOfCourses = admin.viewCourse();
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Course ID"+"\t\t"+"Course Name"+"\t\t\t"+"No of days"+"\t\t");
					System.out.println("------------------------------------------------------------------------");
										
					for(CourseMaster courseObj: listOfCourses){
						System.out.println(courseObj.getCourseID()+"\t\t\t"+courseObj.getCourseName()+"\t\t\t"+courseObj.getNoOfDays());
					}
					
					System.out.println();
					System.out.print("Enter the course ID you want to delete: ");
					courseIDStr = in.next();
					
					while(admin.checkIfInt(courseIDStr) == false){
						System.out.println();
						System.out.println("<< Please enter valid course ID to delete >>");						
						courseIDStr = in.next();
					}
					
					courseID = Integer.parseInt(courseIDStr);					
					//the entered course id is then sent to delete from the database
					int stat = admin.deleteCourse(courseID);
					if(stat>0){
						System.out.println("You have deleted the course "+courseID);
					}
					System.out.println("No courses were deleted");				
					break;
				case "4": break label1;
				default: System.out.println("<< Please choose options from 1-4 only >>");
			   }
			}while(true);
						break;
				
			case "3" :
				System.out.println("=====================");
				System.out.println("FEEDBACK REPORT");
				System.out.println("=====================");
				
				label2: do{	
				System.out.println();
				System.out.println("1) Training Feedback Report for month");
				System.out.println("2) Faculty Feedback Report for month");
				System.out.println("3) General Feedback Report");
				System.out.println("4) Exit");
				
				String opt = in.next();				
								
					switch(opt){
					case "1": 
						System.out.println();
						System.out.println("=========================================");
						System.out.println("MONTHLY TRAINING PROGRAM FEEDBACK");
						System.out.println("=========================================");
						
						System.out.println();
						System.out.print("Enter the month (1-12) you want to view feedback for: ");							
						monthStr = in.next();
						
						while(coordinator.checkMonth(monthStr) == false){
							System.out.println();
							System.out.println("<< Please enter valid month to view feedback >>");
							monthStr = in.next();
						}					
						
						month = Integer.parseInt(monthStr);
						ArrayList<Feedback> feedbackList = feedback.viewTrainingProgramReport(month);
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: feedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}
						
						float average = feedback.findMonthlyAverage(month);
						System.out.println();
						System.out.println("Average Score: "+ average);											
						break;
						
					case "2":
						System.out.println();
						System.out.println("===========================");
						System.out.println("MONTHLY FACULTY FEEDBACK");
						System.out.println("===========================");						
						System.out.println();
						System.out.print("Enter the month(1-12) you want to view feedback for: ");
						monthStr = in.next();
						
						while(coordinator.checkMonth(monthStr) == false){
							System.out.println();
							System.out.println("<< Please enter valid month to view feedback >>");
							monthStr = in.next();
						}						
						month = Integer.parseInt(monthStr);
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						ArrayList<Feedback> facultyFeedbackList = feedback.viewFacultyProgramReport(month);
						
						for(Feedback feedbackObj: facultyFeedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}
									
						break;
					case "3": 
						System.out.println();
						System.out.println("=====================");
						System.out.println("GENERAL FEEDBACK");
						System.out.println("=====================");
						
						ArrayList<Feedback> generalFeedbackList = feedback.viewGeneralFeedback();
						System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Participant name"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: generalFeedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getParticipantID()+"\t\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}						
						break;
					case "4": break label2;
					default: System.out.println("<< Please choose a valid option >>");		
					
					}					
					}while(true);
				
					break;
			case "4": System.out.println("======================");
					System.out.println("Good Bye "+employee.getEmployeeName());
					System.out.println("See you next time!");
					System.exit(0);
			default: System.out.println("<< Please choose an option from 1-4 >>");
			}
		 }while(true);	
		
		}							
		
		//if the user is a coordinator then he can choose to perform training program maintenance or particpant enrollment
		else if(employee.getRole().equalsIgnoreCase("Coordinator")){
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
			do{
			System.out.println();
			System.out.println("Choose the action you want to perform: ");
			System.out.println("------------------------------------");
			System.out.println("|1) Training Program Maintenance   |");
			System.out.println("|2) Participant Enrolling          |");
			System.out.println("|3) View Feedback Report           |");
			System.out.println("|4) Log out                        |");
			System.out.println("------------------------------------");
			
			choice  = in.next();		
			
			switch(choice){
			case "1":
				label3: do{
				System.out.println();
				System.out.println("****** Training Maintenance ******");
				System.out.println();
				System.out.println("Choose the action you want to perform");
				System.out.println("-----------------------------");
				System.out.println("|1) View training details   |");
				System.out.println("|2) Add new training        |");
				System.out.println("|3) Delete training         |");
				System.out.println("|4) Exit                    |");
				System.out.println("-----------------------------");	
				
				option = in.next();
				
				switch(option){
				case "1": 
					ArrayList<TrainingProgram> trainingProgramList = coordinator.viewTrainingList();
					
					System.out.println("Training Code"+"\t"+"Course Code"+"\t"+"Course Name"+"\t"+"Faculty Code"+"\t"+"Start Date"+"\t"+"End Date");
					System.out.println("-----------------------------------------------------------------------------------");
					for(TrainingProgram trainingProgramObj: trainingProgramList){
						System.out.println(trainingProgramObj.getTrainingCode()+"\t\t"+trainingProgramObj.getCourseCode()+"\t\t"+trainingProgramObj.getCourseName()+"\t\t"+trainingProgramObj.getFacultyCode()+"\t\t"+trainingProgramObj.getStartDate()+"\t\t"+trainingProgramObj.getEndDate());
						
					}
					break;
					
				case "2": 
					count = 0;
					System.out.println();					
					System.out.println("Course List");										
					ArrayList<CourseMaster> courseList = coordinator.viewCourseList();				
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Course ID"+"\t\t"+"Course Name"+"\t\t\t"+"No of days"+"\t\t");
					System.out.println("------------------------------------------------------------------------");
					
					for(CourseMaster courseObj: courseList){
						System.out.println(courseObj.getCourseID()+"\t\t"+courseObj.getCourseName()+"\t\t"+courseObj.getNoOfDays());
					}	
										
					System.out.print("Choose course to add to the training program: ");
					courseIDStr = in.next();
					
					while(coordinator.checkIfInt(courseIDStr) == false){
						System.out.println();
						System.out.println("<< Please enter valid course ID to add >>");
						courseIDStr = in.next();
					}
					
					courseID = Integer.parseInt(courseIDStr);	
					course.setCourseID(courseID);
										
					System.out.println("Choose Faculty");					
					System.out.println("Faculty List");
					System.out.println("----------------------------------------");
					
					ArrayList<FacultySkill> facultySkillList = coordinator.viewFacultyList();
					
					System.out.println("Faculty ID"+"\t\t"+"Faculty SKill");
					for(FacultySkill facultySkillObj: facultySkillList){
						System.out.println(facultySkillObj.getFacultyID()+"\t\t"+facultySkillObj.getSkillSet());
					}
					
					facultyIDStr = in.next();
				
					while(coordinator.checkIfInt(facultyIDStr) == false){
						System.out.println();
						System.out.println("<< Please enter valid faculty ID to add >>");	
						facultyIDStr = in.next();
					}
					
					facultyID = Integer.parseInt(facultyIDStr);					
					DateValidator checkDate = new DateValidator();
					
					System.out.print("Enter the start date in (DD/MM/YYYY): ");
					startDateStr = in.next();
					while(checkDate.validate(startDateStr) == false){
						System.out.println();
						System.out.println("<< Please enter a valid date >>");
						startDateStr = in.next();
					}
								
					System.out.print("Enter end date in (DD/MM/YYYY): ");
					endDateStr = in.next();
					while(checkDate.validate(endDateStr) == false){
						System.out.println();
						System.out.println("<< Please enter a valid date >>");
						endDateStr = in.next();
					}
					training.setCourseCode(courseID);
					training.setFacultyCode(facultyID);
					training.setStartDateStr(startDateStr);
					training.setEndDateStr(endDateStr);
										
					int n = coordinator.addNewTraining(training);
					if(n>0){
						System.out.println("You have successfully added the training");
					}
					else{
						System.out.println("Could not add the training");
					   }			 
								
					break;
					
				case "3": 
					System.out.println();					
					System.out.println("Training List");
					System.out.println("----------------------------------------");
					
					ArrayList<TrainingProgram> trainingList = coordinator.viewTrainings();
					
					for(TrainingProgram trainingProgramObj: trainingList){
						System.out.println(trainingProgramObj.getTrainingCode());
					}
					System.out.println();
					System.out.println("Enter the training ID you want to delete from the list:");
					
					trainingCodeStr = in.next();
					
					while(coordinator.checkIfInt(trainingCodeStr) == false){
						System.out.println();
						System.out.println("<< Please enter valid training ID to delete >>");	
						trainingCodeStr = in.next();
					}
					trainingCode = Integer.parseInt(trainingCodeStr);
					training.setTrainingCode(trainingCode);
					
					int stat = coordinator.deleteTraining(training);
					
					if(stat>0){
						System.out.println("You have deleted the training "+trainingCode);
					}
					else{
						System.out.println("No trainings were deleted");
					}
				  
					break;
				case "4": break label3;
				default:System.out.println("<< Please choose options from 1-4 only >>"); 	
				}
				}while(true);
					break; 
			case "2": 
				
				System.out.println("*** PARTICIPANT ENROLL ***");
				System.out.println("=====================================================");
								
				System.out.println("Training Programs");
				System.out.println("--------------------------------------------------------");
				
				ArrayList<TrainingProgram> trainingProgramList = coordinator.viewTrainings();
				System.out.println("Training Code"+"\t\t"+"Course Code"+"\t\t"+"Course Name");
				System.out.println("--------------------------------------------------------");
				
				for(TrainingProgram trainingProgramObj: trainingProgramList){
					System.out.println(trainingProgramObj.getTrainingCode()+"\t\t\t"+trainingProgramObj.getCourseCode()+"\t\t\t"+trainingProgramObj.getCourseName());
				}
				
				System.out.println();
				System.out.print("Enter the training program code to enroll the participant to: ");
				
				trainingCodeStr = in.next();
				
				while(coordinator.checkIfInt(trainingCodeStr) == false){
					System.out.println();
					System.out.println("<< Please enter valid training ID to enroll >>");
					trainingCodeStr = in.next();
				}
				
				trainingCode = Integer.parseInt(trainingCodeStr);				
				System.out.println("---------------------------------------------------");
				System.out.println("Participant list");
				System.out.println("---------------------------------------------------");
				
				ArrayList<Employee> participantList = coordinator.viewParticipantList();
				for(Employee emp: participantList){
					System.out.println(emp.getEmployeeID());
				}
				System.out.println();
				System.out.print("Choose the participant ID to enroll: ");
				employeeIDStr = in.next();
				
				while(coordinator.checkIfInt(employeeIDStr) == false){
					System.out.println();
					System.out.println("<< Please enter valid participant ID to enroll >>");	
					employeeIDStr = in.next();
				}
				
				employeeID = Integer.parseInt(employeeIDStr);
				
				if(coordinator.checkIfValid(trainingCode,employeeID)){				
					int stat = coordinator.participantEnroll(trainingCode, employeeID);				
					if(stat>0){
					System.out.println("You have successfully enrolled participant "+employeeID+" to the training "+trainingCode);
					}
					else{
						System.out.println("No participant was enrolled into a training");
					}
				  }
				else{
					System.out.println();
					System.out.println("<< You have provided an invalid input >>");
				}			
					break;
			case "3":
				System.out.println("*** FEEDBACK REPORT ***");
				System.out.println();
				
				label2: do{	
					
				System.out.println();
				System.out.println("-------------------------------------------");
				System.out.println("|                                          |");
				System.out.println("|   1) Training Feedback Report for month  |");
				System.out.println("|   2) Faculty Feedback Report for month   |");
				System.out.println("|   3) General Feedback Report             |");
				System.out.println("|   4) Exit                                |");
				System.out.println("|                                          |");
				System.out.println("-------------------------------------------");
				
				String opt = in.next();				
								
					switch(opt){
					case "1": 
						System.out.println();
						System.out.println("=========================================");
						System.out.println("MONTHLY TRAINING PROGRAM FEEDBACK");
						System.out.println("=========================================");
						
						System.out.println();
						System.out.print("Enter the month (1-12) you want to view feedback for: ");							
						monthStr = in.next();
						
						while(coordinator.checkMonth(monthStr) == false){
							System.out.println();
							System.out.println("<< Please enter valid month to view feedback >>");
							monthStr = in.next();
						}					
						
						month = Integer.parseInt(monthStr);
						ArrayList<Feedback> feedbackList = feedback.viewTrainingProgramReport(month);
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: feedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}
						
						float average = feedback.findMonthlyAverage(month);
						System.out.println();
						System.out.println("Average Score: "+ average);											
						break;
						
					case "2":
						System.out.println();
						System.out.println("===========================");
						System.out.println("MONTHLY FACULTY FEEDBACK");
						System.out.println("===========================");						
						System.out.println();
						System.out.print("Enter the month(1-12) you want to view feedback for: ");
						monthStr = in.next();
						
						while(coordinator.checkMonth(monthStr) == false){
							System.out.println();
							System.out.println("<< Please enter valid month to view feedback >>");
							monthStr = in.next();
						}						
						month = Integer.parseInt(monthStr);
						System.out.println("-----------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						ArrayList<Feedback> facultyFeedbackList = feedback.viewFacultyProgramReport(month);
						
						for(Feedback feedbackObj: facultyFeedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}
									
						break;
					case "3": 
						System.out.println();
						System.out.println("=====================");
						System.out.println("GENERAL FEEDBACK");
						System.out.println("=====================");
						
						ArrayList<Feedback> generalFeedbackList = feedback.viewGeneralFeedback();
						System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						System.out.println("Date"+"\t\t"+"Training"+"\t\t"+"Participant name"+"\t\t"+"Faculty"+"\t\t"+"Pres&COmm"+"\t\t"+"ClrfyDbt"+"\t"+"Time Mgmt"+"\t"+"Handout"+"\t\t"+"HwSwNw");
						System.out.println("-------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
						
						for(Feedback feedbackObj: generalFeedbackList){
							System.out.println(feedbackObj.getEntryDate()+"\t\t"+feedbackObj.getTrainingCode()+"\t\t"+feedbackObj.getParticipantID()+"\t\t\t"+feedbackObj.getEmployeeName()+"\t\t"+feedbackObj.getFbPrsComm()+"\t\t\t"+feedbackObj.getFbClrfyDbts()+"\t\t"+feedbackObj.getFbTm()+"\t\t"+feedbackObj.getFbHandout()+"\t\t"+feedbackObj.getFbHwSwNtwk());
						}						
						break;
					case "4": break label2;
					default: System.out.println("<< Please choose a valid option >>");						
					}
					
					}while(true);				
					break;
			case "4":
					System.out.println("====================");
					System.out.println("Good Bye "+employee.getEmployeeName());
					System.out.println("See you next time!");
					System.exit(0);
			default: System.out.println("<< Please choose an option from 1-4 >>");
			}
			}while(true);
		}
		else if(employee.getRole().equalsIgnoreCase("Participant")){
			log.info("Entered as participant");
			System.out.println("============ Welcome "+employee.getEmployeeName()+ "============");
			System.out.println("Please rate the training from 1-5 where");
			System.out.println("5 - Excellent:The ideal way of doing it");
			System.out.println("4 - Good:No pain areas or concern but could have been better");
			System.out.println("3 - Average: There are concerns but not significant");
			System.out.println("2 - Below Average: Needs improvement and is salvageable");
			System.out.println("1 - Poor: This way of doing things must change");
						
			System.out.println();
			System.out.println("============ Enter Feedback for the training attended ============");
						
			System.out.print("1) Presentation and communication skills of faculty: ");
			fbPrsCommStr = in.next();
			while(participant.checkFeedbackValue(fbPrsCommStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.println();
				System.out.print("Please enter a number between 1-5: ");
				fbPrsCommStr = in.next();				
			}			
			System.out.print("2) Ability to clarify doubts and explain difficult points: ");
			fbClrfyDbtsStr = in.next();
			while(participant.checkFeedbackValue(fbClrfyDbtsStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5: ");				
				fbClrfyDbtsStr = in.next();				
			}
			System.out.print("3) Time management in completing the contents: ");
			fbTmStr = in.next();
			while(participant.checkFeedbackValue(fbTmStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5: ");
				fbTmStr = in.next();				
			}
			System.out.print("4) Handout provided(Student Guide): ");
			fbHandoutStr = in.next();
			while(participant.checkFeedbackValue(fbHandoutStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5");
				fbHandoutStr = in.next();				
			}
			System.out.print("5) Hardware, software and network availability: ");
			fbHwSwNtwkStr = in.next();
			while(participant.checkFeedbackValue(fbHwSwNtwkStr) == false){
				log.info("Invalid feedback input was provided");
				System.out.print("Please enter a number between 1-5");
				fbHwSwNtwkStr = in.next();
			}
			System.out.print("Comments:");
			String dummy = in.nextLine();
			comments = in.nextLine();
			
			/*while(participant.checkIfValidMessage() == false){
				log.info("Comments provided was of inadequate length");
				System.out.println("Provide minimum input of 10 characters");
			}*/
			System.out.print("Suggestions:");
			suggestions = in.nextLine();
						
			fbPrsComm = Integer.parseInt(fbPrsCommStr);
			fbClrfyDbts = Integer.parseInt(fbClrfyDbtsStr);
			fbTm = Integer.parseInt(fbTmStr);
			fbHandout = Integer.parseInt(fbHandoutStr);
			fbHwSwNtwk = Integer.parseInt(fbHwSwNtwkStr);
		
			// The feedback entered by the user is then set in the bean class
			feed.setFbPrsComm(fbPrsComm);
			feed.setFbClrfyDbts(fbClrfyDbts);
			feed.setFbTm(fbTm);
			feed.setFbHandout(fbHandout);
			feed.setFbHwSwNtwk(fbHwSwNtwk);
			feed.setComments(comments);
			feed.setSuggestions(suggestions);
						
			status = participant.provideFeedback(employee, feed);
			//if status is greater than 0 it means rows were updated and hence a display message can be displayed
			if(status>0){
				System.out.println("Thank you for the feedback!");
				System.exit(0);
			 }
			else{
				System.out.println("Sorry! Could not update your feedback.");
			}			
		   }
		}		
		else{
			System.out.println();
			System.out.println("<< You have entered the wrong credentials >>");
			attempt++;	
		 }
			
		}catch(FMSException e){
			System.err.println(e);
		} catch (SQLException e) {
			System.err.println(e);
		}
				
		}while(true);
	}

}
