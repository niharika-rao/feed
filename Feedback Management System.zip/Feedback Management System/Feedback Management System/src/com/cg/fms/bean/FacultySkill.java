package com.cg.fms.bean;

public class FacultySkill {
	int facultyID;
	String SkillSet;
	
	public int getFacultyID() {
		return facultyID;
	}
	public void setFacultyID(int facultyID) {
		this.facultyID = facultyID;
	}
	public String getSkillSet() {
		return SkillSet;
	}
	public void setSkillSet(String skillSet) {
		SkillSet = skillSet;
	}
	
}
