package com.cg.fms.service;


import java.sql.SQLException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.fms.bean.Employee;
import com.cg.fms.dao.EmployeeDAOImpl;
import com.cg.fms.dao.IEmployeeDAO;
import com.cg.fms.exception.FMSException;

public class EmployeeServiceImpl implements IEmployeeService {

	IEmployeeDAO dao = new EmployeeDAOImpl();
	@Override
	public boolean login(Employee employee) throws FMSException, SQLException {
		
		return dao.login(employee);
	}

	
    
    public boolean validateUserName(int employeeID){
    	/*String empID = employeeID;
    	Pattern usrNamePtrn = Pattern.compile("\\d{5}");
        Matcher mtch = usrNamePtrn.matcher(employeeID);
        if(mtch.matches()){
            return true;
        }
        return false;*/
    	return false;
    }
}
