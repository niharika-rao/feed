package com.cg.fms.service;

import com.cg.fms.exception.FMSException;

public interface IFeedbackService {

	public int viewFeedback() throws FMSException;
}
