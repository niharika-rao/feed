package com.cg.fms.dto;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.cg.fms.exception.FMSException;

public class DBUtil {
	
public static Connection getConn() throws ClassNotFoundException, SQLException, FMSException{
		
		final String driver = "com.mysql.jdbc.Driver";
		final String url ="jdbc:mysql://localhost:3306/mysql?useSSL=false";		
		final String user="root";
		final String password="niharika";
		Connection conn=null;
		
		Class.forName(driver);
		
		 try {
				conn = DriverManager.getConnection(url,user,password);
			} catch (SQLException e) {
				throw new FMSException("Could not get driver connection");				
			}	
		
		return conn;	
		
	}

}
