package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.fms.bean.Employee;
import com.cg.fms.bean.Feedback;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

public class ParticipantDAOImpl implements IParticipantDAO {

	int trainingCode;
	int participantID;
	int fbPrsComm;
	int fbClrfyDbts;
	int fbTm;
	int fbHandout;
	int fbHwSwNtwk;
	String comments;
	String suggestions;

	// this method is for the participant to provide feedback for the training
	// he attended
	@Override
	public int provideFeedback(Employee employee, Feedback feed) throws FMSException {

		int n = 0;

		PreparedStatement pstmt;
		PreparedStatement pstmt1;
		ResultSet rs;

		Scanner in = new Scanner(System.in);

		// to establish connection with the database
		Connection conn = null;
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}

		participantID = employee.getEmployeeID();

		try {
			// the training id is retrieved from the database based on the
			// employee id
			pstmt = conn.prepareStatement(IQuerymapper.training_Part_Query);
			pstmt.setInt(1, participantID);

			rs = pstmt.executeQuery();
			while (rs.next()) {
				trainingCode = rs.getInt(1);
			}

			// the values so obtained are set in the bean class
			feed.setTrainingCode(trainingCode);
			feed.setParticipantID(participantID);			
			
			fbPrsComm = feed.getFbPrsComm();
			fbClrfyDbts = feed.getFbClrfyDbts();
			fbTm = feed.getFbTm();
			fbHandout = feed.getFbHandout();
			fbHwSwNtwk = feed.getFbHwSwNtwk();
			comments = feed.getComments();
			suggestions = feed.getSuggestions();
			
			// The feedback entered by the participant for a particular training
			// and faculty
			// is then stored in the feedback_master table
			pstmt1 = conn.prepareStatement(IQuerymapper.feedback_entry);
			pstmt1.setInt(1, trainingCode);
			pstmt1.setInt(2, participantID);
			pstmt1.setInt(3, fbPrsComm);
			pstmt1.setInt(4, fbClrfyDbts);
			pstmt1.setInt(5, fbTm);
			pstmt1.setInt(6, fbHandout);
			pstmt1.setInt(7, fbHwSwNtwk);
			pstmt1.setString(8, comments);
			pstmt1.setString(9, suggestions);
			pstmt1.setDate(10, new java.sql.Date(System.currentTimeMillis()));
			
			n = pstmt1.executeUpdate();

		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return n;

	}
}
