package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.fms.bean.CourseMaster;
import com.cg.fms.bean.FacultyMaintenance;
import com.cg.fms.bean.FacultySkill;
import com.cg.fms.bean.TrainingProgram;
import com.cg.fms.dto.DBUtil;
import com.cg.fms.exception.FMSException;

public class AdminDAOImpl implements IAdminDAO {
	PreparedStatement delete_pstmt;
	PreparedStatement pstmt1, pstmt;
	
	int courseCode;
	
	int courseID;
	String courseName;
	int noOfDays;
	
	int facultyID;
	String skillSet;	
	
	int facultyCode;
	
	@Override
	public ArrayList<FacultyMaintenance> facultyMaintenance() throws FMSException {		
		
		
		ArrayList<FacultyMaintenance> listOfFeedback = new ArrayList<>();
		ResultSet rs;
		
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			throw new FMSException("Could not create connection");
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		try {			
			TrainingProgram tp = new TrainingProgram();
			FacultySkill fs = new FacultySkill();
			CourseMaster cm = new CourseMaster();		
			
			pstmt1 = conn.prepareStatement(IQuerymapper.faculty_view);			
			rs = pstmt1.executeQuery();
			while(rs.next()){
				facultyCode = rs.getInt(1);
				skillSet = rs.getString(2);
				courseCode = rs.getInt(3);
				courseName = rs.getString(4);
				noOfDays = rs.getInt(5);
				
				FacultyMaintenance maintenance = new FacultyMaintenance(); 
				
				maintenance.setFacultyCode(facultyCode);
				maintenance.setSkillSet(skillSet);
				maintenance.setCourseCode(courseCode);
				maintenance.setCourseName(courseName);
				maintenance.setNoOfDays(noOfDays);
				
				listOfFeedback.add(maintenance);		
			}						
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		return listOfFeedback;	
		
	}

	@Override
	public ArrayList<CourseMaster> viewCourse() throws FMSException {
				
		PreparedStatement pstmt;
		ResultSet rs;
		
		ArrayList<CourseMaster> courseList = new ArrayList<>();		

		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		try {
			pstmt = conn.prepareStatement(IQuerymapper.course_maintenance);			
			rs = pstmt.executeQuery();
			while(rs.next()){
				courseID = rs.getInt(1);
				courseName = rs.getString(2);
				noOfDays = rs.getInt(3); 
				
				CourseMaster course = new CourseMaster();
				
				course.setCourseID(courseID);
				course.setCourseName(courseName);
				course.setNoOfDays(noOfDays);
				
				courseList.add(course);
				//System.out.println(courseID+ " \t\t" + courseName+ "\t\t\t\t" +noOfDays);
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return courseList;
	}



	@Override
	public int addNewCourse(CourseMaster course) throws FMSException {
		
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		courseName = course.getCourseName();
		noOfDays = course.getNoOfDays();
		
		int n;
		try {
			pstmt = conn.prepareStatement(IQuerymapper.add_course);
			
			pstmt.setString(1, courseName);
			pstmt.setInt(2, noOfDays);
				
			n = pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new FMSException("Had a problem while executing the query");
		}
		return n;
	}



	@Override
	public int deleteCourse(int courseID) throws FMSException {
		
		int n;
		
		Connection conn = null;		
		try {
			conn = DBUtil.getConn();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		} catch (SQLException e1) {
			e1.printStackTrace();
		}
		
		try {
			delete_pstmt = conn.prepareStatement(IQuerymapper.delete_course);
			delete_pstmt.setInt(1, courseID);
			n = delete_pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new FMSException("Could not execute delete_course query");
		}		
		return n;
	}

}
